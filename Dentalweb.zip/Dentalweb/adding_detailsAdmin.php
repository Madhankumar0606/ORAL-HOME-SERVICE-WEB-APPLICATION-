<?php


include('connection.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['addTest']))
 {
    $name = $_POST['name'];
    
    $status = isset($_POST['status']) ? 1 : 0;
    $popular = isset($_POST['popular']) ? 1 : 0;

    $image = $_FILES['image']['name'];
    $path = "uploads/";
    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_ext;

    $test_query = "INSERT INTO testType (name, status, popular, image) 
              VALUES ('$name', $status, $popular, '$filename')";

    $test_query_run = mysqli_query($con, $test_query);
    if ($test_query_run) {
        move_uploaded_file($_FILES['image']['tmp_name'], $path . $filename);
        echo '<script>alert("Test Added Successfully");</script>';
        echo '<script>window.location.href = "allTest.php";</script>';

    } else {
        echo '<script>alert("Something Went Wrong");</script>';
        echo '<script>window.location.href = "addTest.php";</script>';
    }
    if (!$test_query_run) {
        echo "SQL Error: " . mysqli_error($con);
    }
    
}

else if(isset($_POST['addproduct']))
{
    $test_id = $_POST['test_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
   
    $original_price = $_POST['original_price'];
    $selling_price = $_POST['selling_price'];
   
    $image = $_FILES['image']['name'];
    
    $path = "uploads/";
    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $filename = time() . '.' . $image_ext;

    $test_query = "INSERT INTO alltest (test_id,name,slug,original_price, selling_price) 
              VALUES ('$test_id','$slug',' $name', '$original_price','$selling_price')";

    $test_query_run = mysqli_query($con, $test_query);
    if ($test_query_run) {
        move_uploaded_file($_FILES['image']['tmp_name'], $path . $filename);
        echo '<script>alert("Test Added Successfully");</script>';
        echo '<script>window.location.href = "addAlltestList.php";</script>';

    } 
        else {
           echo '<script>alert("Something Went Wrong: ' . mysqli_error($con) . '");</script>';
            echo '<script>window.location.href = "addTest.php";</script>';
        }
        
    }
   /* if (!$test_query_run) {
        echo "SQL Error: " . mysqli_error($con);
    }*/

    else if(isset($_POST['updateprofileAdmin'])) {
        // Check if the fields exist in the POST data before using them
        if (isset($_POST['id'], $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['password'])) {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $password = $_POST['password'];
            $cpassword = $_POST['cpassword'];
            $age=$_POST['age'];
            $gender=$_POST['gender'];
            
            // Use double quotes to specify column names and their new values in the SQL query
            $update_query = "UPDATE register SET name='$name', email='$email', phone='$phone', password='$password' ,age='$age',gender='$gender',cpassword='$cpassword' WHERE id = $id";
    
            $update_query_run = mysqli_query($con, $update_query);
    
            if ($update_query_run) {
                echo '<script>alert("Update successful");</script>';
                echo '<script>window.location.href = "user_view.php";</script>';
            } else {
                echo "Update failed: " . mysqli_error($con); // Display the error message for debugging
            }
        } else {
            echo "Some fields are missing in the POST data.";
        }
    }
    

    
    else if(isset($_POST['updateDoctorProfileAdmin'])) {
        // Check if the fields exist in the POST data before using them
        if (isset($_POST['id'], $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['password'])) {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $password = $_POST['password'];
            $cpassword = $_POST['cpassword'];
            $age=$_POST['age'];
            $gender=$_POST['gender'];
            $specialist = $_POST['specialist'];
            
            // Use double quotes to specify column names and their new values in the SQL query
            $update_query = "UPDATE register SET name='$name', email='$email', phone='$phone', password='$password' ,age='$age',gender='$gender',cpassword='$cpassword' ,specialist='$specialist'WHERE id = $id";
    
            $update_query_run = mysqli_query($con, $update_query);
    
            if ($update_query_run) {
                echo '<script>alert("Update successful");</script>';
                echo '<script>window.location.href = "allDoctor.php";</script>';
            } else {
                echo "Update failed: " . mysqli_error($con); // Display the error message for debugging
            }
        } else {
            echo "Some fields are missing in the POST data.";
        }
    }

?>