<?php

include('connection.php');

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "SELECT * FROM prescription WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($result)) {
        $name = $row['name'];
        $age = $row['age'];
        $gender = $row['gender'];
        $number = $row['phone'];
        $detail = $row['detail'];

        // Fetch image paths
        $scan_image = $row['scan_image'];
        $prescription_image = $row['prescription_image'];
    } else {
        echo "User not found";
        exit;
    }
} else {
    echo "User ID not in URL";
    exit;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="booking_type.css">
    <link rel="stylesheet" href="adminSidebar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Patient Details</title>
    <style>
        .headerform{
            background:#126983;
            margin-bottom:20px;
            display:flex;
            justify-content:space-between;
        }
        .headerform div{
            color:white;
            padding:5px;
            font-size:15px;
            margin:5px 0px;
            line-height:25px;
            
        }
        .location{
            display:flex;
            justify-content:space-between;
        }
    .button {
        text-align: center;
    }

    .submitbtn {
        display: inline-block;
        padding: 10px 10px;
         width:80%;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
    }
    img{
        width:100px;
        height:100px;
    }
    </style>
</head>
<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="clinic.php">Test Appointment Date</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="ourdental.png">
        </div>
    <div class="body">
        <form action="" method="post">
            <div class="headerform">
                <img src="ourdental.png" alt="">
                <div class="location">
                    <div>162, Poonamallee High Rd, Velappanchavadi,
                        <BR> Chennai, Tamil Nadu 600077</div>
                    <div>+91 893999424,<br>+044 26801583</div>
</div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="name" id="name" value="<?= $name ?>">
                </div>
            </div>
            <div class="container">
               
</div>
                <div class="container">
                <div class="labelcontainer">
                    <label for="email">Age</label>
                </div>
                <div class="inputcontainer">
                    <input type="number" name="age" id="age"  value="<?= $age ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="gender">Gender</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="gender" id="gender" value="<?= $gender ?>">
                  
                </div>
               </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="number">Mobile Number</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="number" id="number"  value="<?= $number ?>">
                </div>
            </div>
        

            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Detail Description About the Patient Symptom</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="problem" id="problem" cols="30" rows="5" ><?= $detail?></textarea>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">X-Ray/ Scan Photo:</label>
                </div>
                <div class="inputcontainer">
                <img src="./Doctor/report/<?= $scan_image ?>" alt="Prescription Photo">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Prescription Photo</label>
                </div>
                <div class="inputcontainer">
    <img src="./Doctor/report/<?= $prescription_image ?>" alt="Prescription Photo">
</div>

            </div>
            <div class="button">
            <a href="prescription_Send_patient.php?id=<?=$id?>"class="submitbtn">OK</a>

            </div>
        </form>
    </div>
</div>
<script src="admin.js"></script>
</body>
</html>