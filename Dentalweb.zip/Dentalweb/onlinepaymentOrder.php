<?php
include('function.php');
function getAllOrderOnline()
{
   global $con;
   $query="SELECT * FROM  orders WHERE payment_mode='online'";
   return mysqli_query($con,$query);

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">
    <link rel="stylesheet" href="table.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Add User</title>
    <style>
        /* Add your styles here if needed */
        #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }
        .fa-user-plus{
            margin:5px 10px;
          
        }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="clinic.php">Test Appointment Date</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="ourdental.png">
        </div>
     
    <div class="category" >
        <h2>Online Payment Orders</h2>
     
        <table id="table" id="product_table">
            <thead>
                <tr>
                  
                    <td>Tracking_no</td>
                    <td>Address</td>
                    <td>email</td>
                    
                    <td>View</td>
                  
                </tr>
            </thead>
            <tbody>
                <?php
                $order= getAllOrderOnline();
      
                if (mysqli_num_rows($order) > 0) {
                    foreach ($order as $item) {
                ?>
                <tr>
                    
                    <td><?= $item['tracking_no']; ?></td>
                    <td><?= $item['address']; ?></td>
                    <td> <?= $item['email']; ?> </td>


                    <td>
                            <a href="view-orderAdmin.php?t=<?= $item['tracking_no']; ?>" class="btn btn-warning">View</a>
                        </td>
                   
                    </div>
                </tr>
                <?php
                    }
                } else {
                    echo "No records Found";
                }
                ?>
            </tbody>
        </table>
    </div>
            </div>
            </div>
            <script src="admin.js"></script>
</body>

</html>
