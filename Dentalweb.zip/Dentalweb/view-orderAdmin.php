<?php
include('connection.php');
function checkTrackingNoValid($trackingNo)
{
    global $con;
    
    $query="SELECT * FROM orders WHERE tracking_no='$trackingNo'";
    return mysqli_query($con,$query);
}
if (isset($_POST['viewbtn'])) {
    // Check if 'tracking_no' is set in the form or in the URL
    $tracking_no = isset($_POST['tracking_no']) ? $_POST['tracking_no'] : (isset($_GET['t']) ? $_GET['t'] : null);
} else {
    
}

if (isset($_GET['t'])) {
    $tracking_no = $_GET['t'];
    $orderData = checkTrackingNoValid($tracking_no);
    if (mysqli_num_rows($orderData) > 0) {
        $data = mysqli_fetch_array($orderData);
      

        $order_query = "SELECT o.id as oid, o.tracking_no, oi.*, p.* FROM orders o, order_items oi, alltest p WHERE oi.order_id=o.id AND p.id=oi.test_id AND o.tracking_no='$tracking_no'";
        $order_query_run = mysqli_query($con, $order_query); // Ensure $con is your database connection

        if ($order_query_run) {
            ?>
          <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSidebar.css">
    <link rel="stylesheet" href="view-order.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .mainbody {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .user-details, .order-details {
            margin-bottom: 20px;
        }

        h2, h4 {
            margin: 0;
            padding:5px;
            color: #333;
        }

        hr {
            border: 1px solid #ddd;
            margin: 10px 0;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .reason {
            display: none;
        }

        .totalprice {
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
            text-align:right;
            margin-right:50px;
        }

        .total {
            color: red;
            
        }
    </style>
    <title>View Order</title>
</head>
<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="clinic.php">Test Appointment Date</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="ourdental.png">
        </div>
    <section class="mainbody">
        <div class="user-details">
            <h2>User Details</h2>
            <hr>
            <h4><label>Email:</label><?php echo $data['email']; ?></h4>
            <h4><label>Phone:</label> <?php echo $data['phone']; ?></h4>
            <h4><label>Address:</label> <?php echo $data['address']; ?></h4>
        </div>
        <div class="order-details">
            <h2>Order Details</h2>
            <hr>
            <form action="" method="post" id="cancelForm">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Test name</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $totalPrice = 0; // Initialize total price

                        while ($item = mysqli_fetch_array($order_query_run)) {
                            ?>
                            <tr>
                              
                                <td><?php echo $item['name']; ?></td>
                                <td><?php echo $item['total_price']; ?></td>
                                <td style="display:none;">
                                    <input type="hidden" name="test_id[]" value="<?php echo $item['test_id']; ?>">
                                    <input type="hidden" name="order_id" value="<?php echo $item['oid']; ?>">
                                </td>
                                
                            </tr>
                            <?php
                            // Calculate total price for each item
                            $totalPrice += $item['selling_price'];
                        }
                        // Add a row for doctor fee
                        ?>
                        <tr>
                            <td>Doctor Fee</td>
                            <td>₹99</td>
                        </tr>
                    </tbody>
                </table>
            </form>
            <div class="totalprice">Total Price: <span class="total">₹<?php echo $totalPrice + 99; ?></span></div>
            <hr>
            <div class="payment-details">
            <h2>User Details</h2>
            <hr>
           
            <h4><label>Payment Mode:</label> <?php echo $data['payment_mode']; ?></h4>
            <?php
if ($data['online_pay'] != null) {
    echo "<h4><label>Online Pay:</label> {$data['online_pay']}</h4>";
}
?>

        </div>
            <input type="hidden" name="tracking_no" value="<?php echo $tracking_no; ?>">
        </div>

    </section>
</div>
<script src="admin.js"></script>
</body>
</html>

            <?php
        } else {
            echo "Error in fetching order details: " . mysqli_error($con);
        }
    } else {
        echo "<h4>Order not found or permission denied</h4>";
    }
} else {
    echo "<h4>Something went wrong</h4>";
    // Handle the case where 't' is not set
}
?>
