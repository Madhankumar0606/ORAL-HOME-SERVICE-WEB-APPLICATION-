<?php

include('connection.php');
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "SELECT * FROM appointment WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($result)) {
        $name = $row['name'];
        $email = $row['email'];
        $age = $row['age'];
        $gender = $row['gender'];
        $number = $row['phone'];
        $address = $row['address'];
        $location = $row['location'];
        $problem = $row['problem'];
    } else {
        echo "User not found";
        exit;
    }
} else {
    echo "User ID not in URL";
    exit;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./booking_type.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Patient Details</title>
    <style>
    .button {
        text-align: center;
    }

    .submitbtn {
        display: inline-block;
        padding: 10px 10px;
         width:70%;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
    }
    </style>
</head>
<body>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">
    <title>Admin Panel</title>
    <style>
        /* Add your styles here if needed */
        #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="clinic.php">Test Appointment Date</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="ourdental.png">
        </div>
    <div class="body">
        <form action="" method="post">
            <div class="container">
                <div class="labelcontainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="name" id="name" value="<?= $name ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="email">Email</label>
                </div>
                <div class="inputcontainer">
                    <input type="email" name="email" id="email" value="<?= $email ?>">
                </div>
</div>
                <div class="container">
                <div class="labelcontainer">
                    <label for="email">Age</label>
                </div>
                <div class="inputcontainer">
                    <input type="number" name="age" id="age"  value="<?= $age ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="email">Gender</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="gender" id="gender" value="<?= $gender ?>">
                  
                </div>
               </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="number">Mobile Number</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="number" id="number"  value="<?= $number ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="address">address</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="address" id="address" cols="30" rows="5"><?= $address ?></textarea>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="location">Location</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="location" id="location"  value="<?= $location?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Dental Problem Description</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="problem" id="problem" cols="30" rows="5" ><?= $problem ?></textarea>
                </div>
            </div>
            <div class="button">
            <a href="all_appointment.php" class="submitbtn">OK</a>

            </div>
        </form>
    </div>
</div>
<script src="admin.js"></script>
</body>
</html>
