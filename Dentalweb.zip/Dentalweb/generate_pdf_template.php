<?php
// Create a PDF document
$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('times', '', 12);

// Output prescription details
$pdf->Cell(0, 10, 'Prescription Details', 0, 1, 'C');
$pdf->Ln();
$pdf->Cell(0, 10, "Name: $name", 0, 1);
// ... Output other details ...

// Output images
$pdf->Cell(0, 10, 'X-Ray/Scan Photo:', 0, 1);
$pdf->Image($scan_image, 15, $pdf->GetY(), 80);
$pdf->Ln();

$pdf->Cell(0, 10, 'Prescription Photo:', 0, 1);
$pdf->Image($prescription_image, 15, $pdf->GetY(), 80);

// Save the PDF file
$pdf->Output('prescription_details.pdf', 'D');
exit;
?>
