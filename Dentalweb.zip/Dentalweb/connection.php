<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dental";

// Create a connection to the database
$con = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
?>
