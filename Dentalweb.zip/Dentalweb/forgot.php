<?php
include('connection.php');

session_start(); // Start the session

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

    // Check if password and cpassword are equal
    if ($password === $cpassword) {
        // Check if the email exists in the database
        $check_email_query = "SELECT id FROM admin WHERE email='$email'";
        $check_email_result = mysqli_query($con, $check_email_query);

        if (mysqli_num_rows($check_email_result) > 0) {
            // Assuming you have an user_id to identify the user whose password needs to be updated
            $admin_id = mysqli_fetch_assoc($check_email_result)['id'];

            // Update the password for the specific user
            $forgot_query = "UPDATE register SET password='$password', cpassword='$cpassword' WHERE id=$admin_id";
            $forgot_query_run = mysqli_query($con, $forgot_query);

            if ($forgot_query_run) {
                echo '<script>alert("Password updated successfully");</script>';
                echo '<script>window.location.href = "admin_login.php";</script>';
            } else {
                echo '<div class="error-message">Error updating password: ' . mysqli_error($con) . '</div>';
            }
        } else {
            echo '<div class="error-message">Email not found. Please enter a valid email address.</div>';
        }
    } else {
        echo '<div class="error-message">Password and Confirm Password do not match</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        .password {
            margin-bottom: 15px;
            display:flex;
            justify-content:space-between;
        }

        label {
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
            text-align:right;
        }

        input {
            padding: 8px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group {
            margin-top: 15px;
        }

        input[type="submit"] {
            background-color:rgb(0, 99, 160);
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color:#126983;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="post">
        <div class="password">
                    <div class="label">
                    <label for="email">Email</label></div>
                    <div class="input">
                    <input type="email" name="email" id="email" required></div>
                </div>
                <div class="password">
                <div class="label">
                    <label for="password">New Password</label></div>
                    <div class="input">
                    <input type="password" name="password" id="password" required></div>

                </div>
                <div class="password">
                <div class="label">
                
                    <label for="cpassword">Confirm Password</label></div>
                    <div class="input">
                    <input type="password" name="cpassword" id="cpassword" required></div>
                </div>
            <div class="form-group">
                <input type="submit" value="Update Password">
            </div>
        </form>
    </div>
</body>
</html>
