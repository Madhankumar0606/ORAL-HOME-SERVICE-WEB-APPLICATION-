<?php
include('connection.php');
session_start();
function getAppointment()
{
    global $con;
    $userId = $_SESSION['auth_user']['user_id'];
    $query = "SELECT * FROM appointment WHERE user_id = '$userId'";
    $query_run = mysqli_query($con, $query);

    if (!$query_run) {
        // Handle the case where the query execution fails
        echo "Error: " . mysqli_error($con);
        return false; // Return false to indicate an error
    }

    return $query_run; // Return the query result (whether it's empty or contains data)
}


function getAll($table) {
    global $con; // Assuming $con is your database connection

    $query = "SELECT * FROM $table";
    $result = mysqli_query($con, $query);

    if (!$result) {
        die("Error: " . mysqli_error($con));
    }

    return $result;
}
function getAllActive($table)
{
    global $con;
    $query="SELECT * FROM $table WHERE status ='0' ";
    return $query_run=mysqli_query($con,$query);
}
/*function getSlugActive($table, $slug) {
    global $con; 

    $query = "SELECT * FROM $table WHERE slug='$slug' AND status ='0' LIMIT 1";
    $query_run = mysqli_query($con, $query);

    if (!$query_run) {
        die("Error in getSlugActive: " . mysqli_error($con));
    }

    return $query_run;
}

function getTestByType($table, $test_id) {
    global $con; 

    $query = "SELECT * FROM $table WHERE test_id='$test_id' ";
    $query_run = mysqli_query($con, $query);

    if (!$query_run) {
        die("Error in getTestByType: " . mysqli_error($con));
    }

    return $query_run;
}



function getAllTest() {
    global $con;
    $products = array();

    $sql = "SELECT * FROM alltest";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    }

 
    return $products;
}*/
function getTest() {
    global $con;
    $products = array();

    $sql = "SELECT * FROM alltest";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    }

 
    return $products;
}
function getSlugActive($table, $slug)
{
    global $con; 

    $query = "SELECT * FROM $table WHERE slug='$slug' AND status ='0' LIMIT 1";
    $query_run = mysqli_query($con, $query);

    if (!$query_run) {
        die("Error: " . mysqli_error($con));
    }

    return $query_run;
}

function getTestByType($table, $test_id) {
    global $con; 

    $query = "SELECT * FROM $table WHERE test_id='$test_id' AND status ='0'";
    return $query_run = mysqli_query($con, $query);
}


function getTestId($table, $test_id) {
    global $con; 

    $sql = "SELECT * FROM $table WHERE id = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "i", $product_id);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt);
}


// Add this function to your function.php file
function getCartItems()
{
    global $con;

    if (!isset($_SESSION['auth_user']['user_id'])) {
        return array(); 
    }

    $userId = $_SESSION['auth_user']['user_id'];
    
    // Use a JOIN query to retrieve data from both carts and alltest tables
    $query = "SELECT c.id as cid, c.test_id, c.total_price, a.id as pid, a.name, a.selling_price
              FROM carts c
              JOIN alltest a ON c.test_id = a.id
              WHERE user_id = '$userId'
              ORDER BY c.id DESC";

    $query_run = mysqli_query($con, $query);

    if (!$query_run) {
        // Display an error message if the query fails
        echo 'Error executing SQL statement: ' . mysqli_error($con);
        return array(); // Return an empty array
    }

    $cartItems = array(); 

    while ($row = mysqli_fetch_assoc($query_run)) {
        $cartItems[] = $row; // Add each cart item to the array
    }

    return $cartItems; 
}

function generateOrderId($userId)
{
    global $con;

    // Assuming $userId is passed as an argument to the function
    $query = "SELECT c.id as cid, c.test_id, c.total_price, a.id as pid, a.name, a.selling_price
              FROM carts c
              JOIN orders a ON c.user_id = a.user_id
              WHERE user_id = '$userId'
              ORDER BY c.id DESC";
}
function getOrderItems()
{
    global $con;
    $userId = $_SESSION['auth_user']['user_id'];
    $query = "SELECT * FROM orders WHERE user_id = '$userId'";
    $query_run = mysqli_query($con, $query);

    if (!$query_run) {
        // Handle the case where the query execution fails
        echo "Error: " . mysqli_error($con);
        return false; // Return false to indicate an error
    }

    return $query_run; // Return the query result (whether it's empty or contains data)
}

function checkTrackingNoValid($trackingNo)
{
    global $con;
    $userId=$_SESSION['auth_user']['user_id'];
    $query="SELECT * FROM orders WHERE tracking_no='$trackingNo' AND user_id='$userId'";
    return mysqli_query($con,$query);
}
function getAllOrder() {
    global $con;
    $orders = array();

    $sql = "SELECT * FROM orders";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $orders[] = $row;
        }
    }

 
    return  $orders;
}




//admin


function   getAllUsers()
{
   global $con;
   $query="SELECT * FROM register";
   return mysqli_query($con,$query);

}


function getByID($table,$id)
{
    global $con; 

    $query = "SELECT * FROM $table WHERE id='$id'";
    return $query_run=mysqli_query($con,$query);

}

function  getAllDoctor()
{
   global $con;
   $query="SELECT * FROM doctor_register";
   return mysqli_query($con,$query);

}
function  getAllTest()
{
   global $con;
   $query="SELECT * FROM alltest";
   return mysqli_query($con,$query);

}
function getAllOrderAdmin()
{
   global $con;
   $query="SELECT * FROM  orders";
   return mysqli_query($con,$query);

}
function getAllAvailable()

{
   global $con;
   $query="SELECT * FROM doctor_register WHERE STATUS='available'";
   return mysqli_query($con,$query);

}
function getAllUnavailable()

{
   global $con;
   $query="SELECT * FROM doctor_register WHERE STATUS='unavailable'";
   return mysqli_query($con,$query);

}
function getAllHoliday()

{
   global $con;
   $query="SELECT * FROM doctor_register WHERE STATUS='holiday'";
   return mysqli_query($con,$query);

}
function getAllFeedback()

{
   global $con;
   $query="SELECT * FROM feedback";
   return mysqli_query($con,$query);

}

?>