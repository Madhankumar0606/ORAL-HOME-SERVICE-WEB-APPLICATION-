

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
include('connection.php');
require_once('TCPDF-6.4.1/tcpdf.php');

// Fetch prescription data
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM prescription WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $name = $row['name'];
        $age = $row['age'];
        $gender = $row['gender'];
        $number = $row['phone'];
        $detail = $row['detail'];
        $scan_image = $_SERVER['DOCUMENT_ROOT'] . '/Dentalweb/Doctor/report/' . $row['scan_image'];
        $prescription_image = $_SERVER['DOCUMENT_ROOT'] . '/Dentalweb/Doctor/report/' . $row['prescription_image'];

        // Create a PDF document
        $pdf = new TCPDF();
        $pdf->AddPage();
        $pdf->SetFont('times', '', 12);

        ob_start();
        include('connection.php');
        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                .headerform {
                    background-color: #126983;
                    margin-bottom: 20px;
                }

                .headerform img {
                    height: 50px;
                    width: 50px;
                    margin-right: 10px;
                }

                .location {
                    font-size: 11px;
                    color: white;
                    margin-top:-10px;
                }
            </style>
        </head>
        <body>
            <div class="headerform">
                <img src="LOGO1.png" alt="">
                <span class="location">
                    162, Poonamallee High Rd, Velappanchavadi, Chennai, Tamil Nadu 600077<br>
                    +91 893999424,&nbsp; +044 26801583
            </span>
            </div>
        </body>
        </html>

        <?php
        // Get the buffer contents and clean the buffer
        $buffer = ob_get_clean();

        // Output preheader content
        $pdf->writeHTML($buffer, true, false, true, false, '');

        $pdf->Cell(0, 10, 'Prescription Details', 0, 1, 'C');
        $pdf->Ln();
        $pdf->Cell(0, 10, "Name: $name", 0, 1);
        $pdf->Cell(0, 10, "Age: $age", 0, 1);
        $pdf->Cell(0, 10, "Gender: $gender", 0, 1);
        $pdf->Cell(0, 10, "Mobile Number: $number", 0, 1);
        $pdf->Cell(0, 10, "Symptom Description: $detail", 0, 1);
        $pdf->Ln();

        // Output scan image in PDF
        $pdf->Cell(0, 10, "X-Ray/Scan Photo:", 0, 1);
        $pdf->Image($scan_image, 15, $pdf->GetY(), 90);

        $pdf->Ln();

        // Output prescription image in PDF
        $pdf->Cell(0, 10, "Prescription Photo:", 0, 1);
        $pdf->Image($prescription_image, 15, $pdf->GetY(), 90);

        $pdf->Ln();

        // Output the PDF for download
        $pdf->Output('prescription_details.pdf', 'D');
        exit;
    } else {
        echo "User not found";
        exit;
    }
} else {
    echo "User ID not in URL";
    exit;
}
?>
