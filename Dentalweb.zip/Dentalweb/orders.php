<?php
include('header.html');
include('connection.php');
include('function.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['payPrice'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $flat_no = mysqli_real_escape_string($con, $_POST['no']);
    $paymentMode = mysqli_real_escape_string($con, $_POST['payment']);
    
    // Check if 'online_pay' is set before using it
    $online_pay = isset($_POST['online_pay']) ? mysqli_real_escape_string($con, $_POST['online_pay']) : '';

    if ($email == "" || $phone == "" || $flat_no == "" || $address == "" || $paymentMode == "") {
        echo "All fields are required";
        header('Location:order2.php');
        exit(0);
    }

    // Calculate the total price of the order
    $items = getCartItems();
    $total_price = 0;

    foreach ($items as $citem) {
        $total_price += $citem['selling_price'];
    }

    // Start a database transaction
    mysqli_autocommit($con, false);

    $error = false;

    $tracking_no = "dental" . rand(1111, 9999) . substr($phone, 2);
    $user_id = $_SESSION['auth_user']['user_id'];

    $insert_query = "INSERT INTO orders (tracking_no, user_id, phone, email, total_price, address, flat_no, payment_mode,online_pay) VALUES ('$tracking_no', '$user_id', '$phone', '$email', '$total_price', '$address', '$flat_no', '$paymentMode','$online_pay')";

    $insert_query_run = mysqli_query($con, $insert_query);

    if (!$insert_query_run) {
        $error = true;
        // Log the error
        echo "Error: " . mysqli_error($con);
    }

    $order_id = mysqli_insert_id($con);

    foreach ($items as $citem) {
        $test_id = $citem['test_id'];
        $price = $citem['selling_price'];

        $insert_items_query = "INSERT INTO order_items (order_id, user_id, test_id, total_price) VALUES ('$order_id', '$user_id', '$test_id', '$price')";

        $insert_items_query_run = mysqli_query($con, $insert_items_query);

        if (!$insert_items_query_run) {
            $error = true;
            // Log the error
            echo "Error: " . mysqli_error($con);
        }
    }

    $deleteCartQuery = "DELETE FROM carts WHERE user_id='$user_id'";
    $deleteCartQuery_run = mysqli_query($con, $deleteCartQuery);

    if (!$deleteCartQuery_run) {
        $error = true;
        // Log the error
        echo "Error: " . mysqli_error($con);
    }

    // Commit the transaction if no errors occurred, otherwise rollback
    if (!$error) {
        mysqli_commit($con);

        // Redirect to the success page
        header('location:orderSuccess.php');
        exit();
    } else {
        mysqli_rollback($con);
    }

    // Re-enable autocommit
    mysqli_autocommit($con, true);

    /* if (!$error) {
        echo "Order placed Successfully";
        $user_id = $_SESSION['auth_user']['user_id'];
        $notification_text = "You have received a new order.";

        $tracking_no_query = "SELECT tracking_no FROM orders WHERE user_id=$user_id";
        $tracking_no_result = mysqli_query($con, $tracking_no_query);
        $tracking_no_row = mysqli_fetch_assoc($tracking_no_result);
        $tracking_no = $tracking_no_row['tracking_no'];

        $insert_notification_query = "INSERT INTO order_notifications (user_id, notification_text, tracking_no) VALUES ('$user_id', '$notification_text', '$tracking_no')";
        mysqli_query($con, $insert_notification_query);

        header('location:orderSuccess.php');
        exit(); // Make sure to exit after header redirection
    } else {
        echo "Order placement failed.";
    } */
}
?>
