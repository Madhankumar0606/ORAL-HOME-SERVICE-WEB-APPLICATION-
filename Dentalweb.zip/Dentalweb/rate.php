<?php
session_start();
include('header.html');
include('connection.php');
if (!isset($_SESSION['auth_user']['user_id'])) {
    header('location: login_register.php');
    exit();
}

$user_id = $_SESSION['auth_user']['user_id'];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rating = $_POST["rating"];
    $feedback_text = $_POST["feedback"];

    // Insert data into the feedback table
    $sql = "INSERT INTO feedback (rating, user_id, feedback_text) VALUES ('$rating', '$user_id', '$feedback_text')";

    if ($con->query($sql) === TRUE) {
        echo '<script>alert("Feedback sent successfully");</script>';
        echo '<script>window.location.href = "userProfile.php";</script>';
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
}

// Close the database connection
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate Us</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            
            min-height: 100vh;
            background-color: #f4f4f4;
        }

        #feedback-container {
            margin:20px;
            text-align: center;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333333;
        }

        p {
            color: #555555;
        }

        #star-rating span {
            font-size: 24px;
            color: #cccccc;
            cursor: pointer;
            transition: color 0.3s;
            margin: 5px;
        }

        #star-rating span.selected {
            color: #ffd700;
        }

        #feedback {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            box-sizing: border-box;
            border: 1px solid #dddddd;
            border-radius: 5px;
            resize: vertical;
        }

        button {
            background-color:rgb(0, 99, 160);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color:#126983;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const starRating = document.getElementById("star-rating");
            const ratingInput = document.getElementById("rating");

            starRating.addEventListener("click", function (event) {
                if (event.target.tagName === "SPAN") {
                    const ratingValue = event.target.dataset.rating;
                    ratingInput.value = ratingValue;

                    const stars = starRating.getElementsByTagName("span");
                    for (const star of stars) {
                        const starValue = star.dataset.rating;
                        star.classList.toggle("selected", starValue <= ratingValue);
                    }
                }
            });
        });
    </script>
</head>
<body>
    <div id="feedback-container">
        <h2>Rate Us</h2>
        <p>Please provide your feedback by rating us:</p>

        <div id="star-rating">
            <span data-rating="1">&#9733;</span>
            <span data-rating="2">&#9733;</span>
            <span data-rating="3">&#9733;</span>
            <span data-rating="4">&#9733;</span>
            <span data-rating="5">&#9733;</span>
        </div>

        <p id="feedback-message"></p>

        <form action="" method="post">
            <textarea name="feedback" id="feedback" cols="30" rows="10" placeholder="Your Feedback"></textarea>
            <input type="hidden" name="rating" id="rating" value="0">
            <button type="submit" name="submitFeedback">Submit</button>
        </form>
    </div>
</body>
</html>
