<?php
include('function.php'); // Include your functions and database connection
include('header.html');

// Check if the form is submitted
if (isset($_POST['viewbtn'])) {
    // Check if 'tracking_no' is set in the form or in the URL
    $tracking_no = isset($_POST['tracking_no']) ? $_POST['tracking_no'] : (isset($_GET['t']) ? $_GET['t'] : null);
} else {
    #echo "Tracking number is not available.";
}

if (isset($_GET['t'])) {
    $tracking_no = $_GET['t'];
    $orderData = checkTrackingNoValid($tracking_no);
    if (mysqli_num_rows($orderData) > 0) {
        $data = mysqli_fetch_array($orderData);
        $userId = $_SESSION['auth_user']['user_id'];

        $order_query = "SELECT o.id as oid, o.tracking_no, oi.*, p.* FROM orders o, order_items oi, alltest p WHERE o.user_id='$userId' AND oi.order_id=o.id AND p.id=oi.test_id AND o.tracking_no='$tracking_no'";
        $order_query_run = mysqli_query($con, $order_query); // Ensure $con is your database connection

        if ($order_query_run) {
            ?>
          <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="view-order.css">
    <style>
     
    </style>
    <title>View Order</title>
</head>
<body>
    <section class="mainbody">
        <div class="user-details">
            <h2>User Details</h2>
            <hr>
            <h4><label>Email:</label><?php echo $data['email']; ?></h4>
            <h4><label>Phone:</label> <?php echo $data['phone']; ?></h4>
            <h4><label>Address:</label> <?php echo $data['address']; ?></h4>
        </div>
        <div class="order-details">
            <h2>Order Details</h2>
            <hr>
            <form action="" method="post" id="cancelForm">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Test name</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $totalPrice = 0; // Initialize total price

                        while ($item = mysqli_fetch_array($order_query_run)) {
                            ?>
                            <tr>
                              
                                <td><?php echo $item['name']; ?></td>
                                <td><?php echo $item['total_price']; ?></td>
                                <td style="display:none;">
                                    <input type="hidden" name="test_id[]" value="<?php echo $item['test_id']; ?>">
                                    <input type="hidden" name="order_id" value="<?php echo $item['oid']; ?>">
                                </td>
                                
                            </tr>
                            <?php
                            // Calculate total price for each item
                            $totalPrice += $item['selling_price'];
                        }
                        // Add a row for doctor fee
                        ?>
                        <tr>
                            <td>Doctor Fee</td>
                            <td>₹99</td>
                        </tr>
                    </tbody>
                </table>
            </form>
            
            <div class="totalprice">Total Price: <span class="total">₹<?php echo $totalPrice + 99; ?></span></div>
            <hr>
            <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
            <input type="hidden" name="tracking_no" value="<?php echo $tracking_no; ?>">
        </div>
    </section>
</body>
</html>

            <?php
        } else {
            echo "Error in fetching order details: " . mysqli_error($con);
        }
    } else {
        echo "<h4>Order not found or permission denied</h4>";
    }
} else {
    echo "<h4>Something went wrong</h4>";
    // Handle the case where 't' is not set
}
?>
