<?php
include('header.html');
include('function.php');
include('connection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="allDetails.css">
    <title>Order Details</title>
    <style>
  
    </style>
</head>

<body>
    <div class="box">
        <div class="container">
            <h4>Orders Details<h4>
            <div class="orderDetails">
                <?php
                $items = getCartItems();
                $overallTotal = 0; // Initialize overall total

                foreach ($items as $citem) {
                    $total_price = $citem['selling_price'];
                    $overallTotal += $total_price;
                    $overallTotal += 99;
                ?>
                    <div class="item-details">
                        <div class="details">
                            <h5><?= $citem['name'] ?></h5>
                            <!-- Add more details as needed -->
                        </div>
                    </div>
                <?php
                }
                ?>
             </div>
             <h4>Price</h4>
             <div class="priceDetails">
                <?php
                $items = getCartItems();
                $overallTotal = 0; // Initialize overall total

                foreach ($items as $citem) {
                    $total_price = $citem['selling_price'];
                    $overallTotal += $total_price;
                ?>
                <?php
                }
                ?>
                <div class="total">
                    <h5>MRP total</h5><h2> ₹<?= $overallTotal ?></h2>
                </div>
                <div class="total">
                    <h5>Doctor Consultation </h5><h2>₹99</h2>
                </div>
                <?php
                $overallTotal += 99;
                ?>
                <div class="total">
                    <h5>Payable Amount</h5><h2 style="color:red">₹<?= $overallTotal ?></h2>
                </div>
            </div>
        </div>
        <div class="PayButton">
    <form action="orders.php" method="post">
        <button type="submit" name="payPrice" class="pay-button">Pay ₹<?= $overallTotal ?>/-</button>
    </form>
</div>

    </div>
</body>

</html>
