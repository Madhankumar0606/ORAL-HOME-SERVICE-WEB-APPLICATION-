
<?php
include('header.html');
include('function.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="my-order.css">
    <style>
      
    </style>
    <title>My Orders</title>
</head>
<body>
    <section class="mainbody">
        <div class="detailsorder">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tracking No</th>
                        <th>Price</th>

                        <th class="date">Date</th>
                        <th class="appoint">Appointment Date</th>
                        <th class="appoint">Appointment Time</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $orders = getOrderItems();
                    if (mysqli_num_rows($orders) > 0) {
                        foreach ($orders as $item) {
                            ?>
                            <tr>
                                <td><?=$item['id']?></td>
                                <td><?=$item['tracking_no']?></td>
                                <td><?=$item['total_price']?></td>
                                <td class="date"><?=$item['created_at']?></td>
                                <?php
                                 if ($item['appointmentDate'] == '0000-00-00' && $item['appointmentTime'] == '00:00:00') {
                                    echo '<td colspan="2" style="text-align:center;color:green;">Processing</td>';
                                } else {
                                    // Display the actual date and time
                                    echo '<td class="date">' . $item['appointmentDate'] . '</td>';
                                    echo '<td class="date">' . $item['appointmentTime'] . '</td>';
                                }
                                ?>
                                
                                <td>
                                    <a href="view-orders.php?t=<?=$item['tracking_no']?>" class="Viewbtn"> View </a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td colspan="5">No order yet</td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>
</body>
<?php
include('footer.php');
?>
</html>
