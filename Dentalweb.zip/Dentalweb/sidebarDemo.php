<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">
    <title>Admin Panel</title>
    <style>
        /* Add your styles here if needed */
        #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
        }

        .header {
            background-color: #126983;
            color: white;
            padding: 20px;
            text-align: center;
        }

        #sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            background-color: #333;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 20px;
            color: white;
            text-align: center;
            top: 0; /* Set the top position to 0 */
        }

        #content {
            margin-left: 250px;
            transition: margin-left 0.1s;
        }

        .content {
            padding: 20px;
        }

        .bodyContent {
            overflow-y: scroll; /* Add scroll only to the content area */
            height: 100vh; /* Set the height to fill the viewport */
        }
    </style>
</head>

<body>
    <div class="header">
        <img src="LOGO1.png" alt="Logo" id="logo">
        Admin Panel
    </div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <!-- Your sidebar content -->
        </ul>
    </div>

    <div id="content" class="bodyContent">
        <!-- Main content area -->
        <h2>Main Content Area</h2>
        <p>This is the main content area. Add your content here.</p>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const content = document.getElementById('content');

            if (sidebar.style.width === '250px') {
                sidebar.style.width = '0';
                content.style.marginLeft = '0';
            } else {
                sidebar.style.width = '250px';
                content.style.marginLeft = '250px';
            }
        }

        function toggleSublist(sublistId) {
            const sidebar = document.getElementById('sidebar');
            const content = document.getElementById('content');
            const sublist = document.getElementById(sublistId);

            // Toggle the sublist visibility
            sublist.style.display = sublist.style.display === 'none' ? 'block' : 'none';

            // Prevent closing the sidebar when clicking on the sublist
            event.stopPropagation();
        }
    </script>
</body>

</html>
