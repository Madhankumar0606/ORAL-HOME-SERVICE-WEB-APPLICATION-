
<?php


include('connection.php');
include('function.php');


function getAppointmentDoctor()
{
    global $con, $userId; // Added $userId
    $appoint_query = "SELECT * FROM appointment"; // Fixed the comparison
    $appoint_query_run = mysqli_query($con, $appoint_query);

    // Fetch the result as an associative array
    $appointments = [];
    while ($row = mysqli_fetch_assoc($appoint_query_run)) {
        $appointments[] = $row;
    }

    return $appointments;
}


$appointments = getAppointmentDoctor();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSidebar.css">
    <title>View Appointment</title>
    <style>
             *
        {
            margin:0;
            padding:0;
            font-family: 'Inter', sans-serif;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

      
      

        .appointmentDetails {
          
            padding: 10px;
            margin:10px 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color:white;
            
        }
        .user{
            display:flex;
            justify-content:space-between;
        }

        strong {
          
            margin: 10px;
           
            display: inline-block;
            width: 150px; 
            text-align: right;
        }

        .appointmentDetails div {
            
        }

        .date {
            font-size: 0.8em;
            color: #888;
        }

        .noAppointment {
            text-align: center;
            font-style: italic;
            color: #888;
        }

        .appointmentInfo {
            display: inline-block;
                color:rgb(0, 99, 160);
            font-weight:700px;
        }
        .box
        {
            display:flex;
            justify-content:space-between;
        }
        .title
        {
            background-color:black;
            color:white;
            padding:10px;
        }
        .viewbutton
        {
            padding: 6px 20px;
            border-radius:5px;
            color:white;
            background-color:#126983;
            border:none;
        }
        .button a{
            text-decoration:none;
        }
    </style>
</head>
<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="LOGO1.Png">
        </div>
    <section class="details">
        <?php
        if (!empty($appointments)) { // Check if appointments array is not empty
            foreach ($appointments as $item) {
                ?>
                <div class="appointmentDetails">
                    <div class="user">
                        <div class="details">
                        <div><strong>Name:</strong><span class="appointmentInfo"><?=$item['name']?></span></div>
                    <div><strong>Age:</strong><span class="appointmentInfo"><?=$item['age']?></span></div>
                    
                    <div><strong>Gender:</strong><span class="appointmentInfo"><?=$item['gender']?></span></div>
                    <div><strong>Phone:</strong><span class="appointmentInfo"><?=$item['phone']?></span></div>
                    <div><strong>Email:</strong><span class="appointmentInfo"><?=$item['email']?></span></div>
                   
                    <div><strong>Address:</strong><span class="appointmentInfo"><?=$item['address']?></span></div>
                  
                
                        </div>
                        <div class="button">
                            <?php if ($item['appointmentDate'] !== '0000-00-00') { ?>
                                <a href="" class="viewbutton" style="background-color:green;"><?= $item['appointmentDate'] ?></a>
                            <?php } ?>
                            <a href="viewPatientDetails_admin.php?id=<?= $item['id'] ?>" class="viewbutton">View</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            ?>
            <div class="noAppointment">No appointments yet.</div>
            <?php
        }
        ?>
    </section>
    </div>
    <script src="admin.js"></script>
</body>
</html>
