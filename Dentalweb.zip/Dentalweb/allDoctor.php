<?php
include('function.php');

function deleteUser($id) {
    global $con;

    $id = mysqli_real_escape_string($con, $id);

    $deleteQuery = "DELETE FROM doctor_register WHERE id = '$id'";
    
    echo "SQL Query: $deleteQuery"; // Debugging line

    if (mysqli_query($con, $deleteQuery)) {
        echo '<script>alert("Deleted Successfully ");</script>';
        echo '<script>window.location.href = "user_view.php";</script>';
    } else {
        echo "Error deleting notification: " . mysqli_error($con);
    }
}
if (isset($_GET['remove_customer'])) {
    $customerId = $_GET['remove_customer'];
    echo "User ID to remove: $customerId"; // Debugging line
    deleteUser($customerId);
    // No need to include header() here, as the JavaScript in the HTML file will handle the redirection
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">
    <link rel="stylesheet" href="table.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Add User</title>
    <style>
        /* Add your styles here if needed */
        #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }
        .fa-user-plus{
            margin:5px 10px;
          
        }
        .addDoctor{
            background-color:#126983;
            color:white;
            border:none;
            padding:8px 10px;
            margin:10px;
        }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="LOGO1.Png">
        </div>

    <div class="category" >
        <h2>Doctor</h2>
         <a href="addDoctor.php"> <button type="submit" name="addDoctor" class="addDoctor" ><i class="fa fa-user-plus"></i>Add Doctor</button></a>
        <table id="table" id="product_table">
            <thead>
                <tr>
                  
                    <td>Name</td>
                    <td>email</td>
                    <td>Mobile</td>
                    
                    <td>View</td>
                    <td>Delete</td>
                </tr>
            </thead>
            <tbody>
                <?php
                $user=getAllDoctor();
                if (mysqli_num_rows($user) > 0) {
                    foreach ($user as $item) {
                ?>
                <tr>
                    
                    <td><?= $item['name']; ?></td>
                    <td><?= $item['email']; ?></td>
                    <td> <?= $item['phone']; ?> </td>


                    <td>
                            <a href="view-doctorDetails.php?id=<?= $item['id']; ?>" class="btn btn-warning">View</a>
                        </td>
                        <td>
                        <a href="?remove_doctor=<?= $item['id']; ?>" class="remove-btn">Remove</a>

                    </td>
                    </div>
                </tr>
                <?php
                    }
                } else {
                    echo "No records Found";
                }
                ?>
            </tbody>
        </table>
    </div>
    </div>
<script src="admin.js"></script>
</body>

</html>
