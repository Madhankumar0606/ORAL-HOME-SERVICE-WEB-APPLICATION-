<?php
session_start();
include('header.html');
include('connection.php');
error_reporting(E_ALL);
ini_set('display_errors', 1);

function getprescription()
{
    global $con;
    if (isset($_SESSION['auth_user']['user_id'])) {
        $user_id = $_SESSION['auth_user']['user_id'];

        

        $prescription_query = "SELECT p.* FROM prescription p
                               JOIN appointment a ON p.app_id = a.id
                               WHERE a.user_id = $user_id";
        $prescription_query_run = mysqli_query($con, $prescription_query);

        if ($prescription_query_run) {
            $prescription_data = array();
            while ($row = mysqli_fetch_assoc($prescription_query_run)) {
                $prescription_data[] = $row;
            }

           

            return $prescription_data;
        } else {
            echo "Error: " . mysqli_error($con);
            return array();
        }
    } else {
        echo "User not logged in.";
        return array();
    }
}

$prescription = getprescription();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Prescription</title>
    <style>
        *
        {
            margin:0;
            padding:0;
            font-family: 'Inter', sans-serif;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

      
      

        .appointmentDetails {
          
            padding: 10px;
            margin:10px 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color:white;
            
        }
        .user{
            display:flex;
            justify-content:space-between;
        }

        strong {
          
            margin: 10px;
           
            display: inline-block;
            width: 150px; 
            text-align: right;
        }

        .appointmentDetails div {
            
        }

        .date {
            font-size: 0.8em;
            color: #888;
        }

        .noAppointment {
            text-align: center;
            font-style: italic;
            color: #888;
        }

        .appointmentInfo {
            display: inline-block;
                color:rgb(0, 99, 160);
            font-weight:700px;
        }
        .box
        {
            display:flex;
            justify-content:space-between;
        }
        .title
        {
            background-color:black;
            color:white;
            padding:10px;
        }
        .viewbutton
        {
            padding: 6px 20px;
            border-radius:5px;
            color:white;
            background-color:#126983;
            border:none;
        }
        .button a{
            text-decoration:none;
        }
    </style>
</head>
<body>
<div class="title">
        <h3>View prescription </h3>
    </div>
    <section class="details">
        <?php
        if (!empty($prescription)) {
            foreach ($prescription as $item) {
        ?>
        <div class="appointmentDetails">
            <div class="user">
                <div class="details">
                    <div><strong>Name:</strong><span class="appointmentInfo"><?=$item['name']?></span></div>
                    <div><strong>Age:</strong><span class="appointmentInfo"><?=$item['age']?></span></div>
                    <div><strong>Gender:</strong><span class="appointmentInfo"><?=$item['gender']?></span></div>
                    <div><strong>Phone:</strong><span class="appointmentInfo"><?=$item['phone']?></span></div>
                </div>
                <div class="button">
                  <a href="viewReport.php?id=<?= $item['id'] ?>" class="viewbutton">View</a>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
        ?>
        <div class="noAppointment">No Prescription yet.</div>
        <?php
        }
        ?>
    </section>
</body>
</html>