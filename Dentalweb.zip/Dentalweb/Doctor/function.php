<?php
include('connection.php');

function getAllActive($table)
{
    global $con;
    $query="SELECT * FROM $table  ";
    return $query_run=mysqli_query($con,$query);
}
?>