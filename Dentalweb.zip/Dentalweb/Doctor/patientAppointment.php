<?php

session_start();
include('connection.php');
include('header2.html');

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location:login.php');
    exit(); // Stop further execution of the script
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../appointment.css">
    <title>Book Appointment </title>
    <style>
        .btn{
            width:100%;
        }
    </style>
</head>
<body>
    <h3>Welcome to Our Dental Clinic, <span><?php echo $_SESSION['auth_user']['name']; ?></span></h3>
  <div class="centerbox">
    <div class="appointtype">
        <div class="book">
            <a href="patientAccept.php">
        <button type="submit" class="btn" name="bookappoint">Patient Appointments</button>
</a>
</div>
<div class="book">
    <a href="report.php">
        <button type="submit" class="btn" name="bookappoint" > Send Prescription Report</button>
        </a>
        </div>
        <div class="book">
    <a href="view_prescription.php">
        <button type="submit" class="btn" name="bookappoint"> Prescription Report</button>
        </a>
        </div>
        <div class="book">
    <a href="available.php">
        <button type="submit" class="btn" name="bookappoint">Today Status</button>
        </a>
        </div>
</div>
</div>
</body>
</html>
