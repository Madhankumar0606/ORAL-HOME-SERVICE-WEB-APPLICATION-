<?php
include('connection.php');

// Assuming the app_id is passed through the URL like: example.com/your_script.php?app_id=123
$app_id = $_GET['id'];

$name = $_POST['name'];
$phone = $_POST['phone'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$date = $_POST['date'];
$time = $_POST['time'];
$description = $_POST['description'];
$prescription_image = $_POST['prescription'];
$scan_image = $_POST['scan']; 

// Check if all required fields are present before inserting into the database
if ($app_id && $name && $phone && $age && $gender && $date && $time && $description ) {
    // Use prepared statements to prevent SQL injection
    $report_query = "INSERT INTO prescription (app_id, name, phone, date, time, age, gender, description, prescription_image, scan_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $con->prepare($report_query);

    // Bind parameters
    $stmt->bind_param("ssssssssss", $app_id, $name, $phone, $date, $time, $age, $gender, $description, $prescription_image, $scan_image);

    // Execute the query
    $report_query_run = $stmt->execute();

    // Check if the query was successful
    if ($report_query_run) {
        echo "Data inserted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "All fields are required!";
}

// Close the database connection
$con->close();
?>
