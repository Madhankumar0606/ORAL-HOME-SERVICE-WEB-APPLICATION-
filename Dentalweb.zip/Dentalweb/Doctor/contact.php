<?php
include('header2.html');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Oral Home</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
        }

        header {
            margin:20px 0px;
            background-color: #126983;
            color: #fff;
            text-align: center;
            padding: 40px 20px;
        }

        header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        header p {
            font-size: 1.2em;
        }

        .section {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        section h2 {
            color: #126983;
            font-size: 2em;
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 1.1em;
            margin-bottom: 5px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #126983;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        button:hover {
            background-color: #fff;
            color: #126983;
        }

        footer {
            background-color: #126983;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        footer p {
            margin: 0;
        }
    </style>
</head>
<body>

    <header>
        <h1>Contact Oral Home</h1>
        <p>Get in touch with us for any inquiries or to schedule an appointment.</p>
    </header>

    <section id="contact-form" class="section">
        <h2>Contact Form</h2>
        <form action="process-contact.php" method="post">
            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Your Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="message">Your Message:</label>
            <textarea id="message" name="message" rows="4" required></textarea>

            <button type="submit" name="submitform">Submit</button>
        </form>
    </section>

    <section id="contact-info"class="section">
        <h2>Contact Information</h2>
        <p>If you prefer other means of communication, feel free to reach us through the following:</p>
        <p><strong>Address:</strong>162, Poonamallee High Rd, Velappanchavadi,
                        Chennai, Tamil Nadu 600077</p>
                   
        <p><strong>Phone:</strong>+91 893999424,+044 26801583</p>
        <p><strong>Email:</strong>websitesaveetha@gmail.com</p>

        <!-- Include any additional contact information or a map if necessary -->
    </section>

  
</body>
</html>
