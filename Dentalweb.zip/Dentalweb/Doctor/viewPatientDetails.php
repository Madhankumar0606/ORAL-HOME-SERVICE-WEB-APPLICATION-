<?php
include('header2.html');
include('connection.php');
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "SELECT * FROM appointment WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($result)) {
        $name = $row['name'];
        $email = $row['email'];
        $age = $row['age'];
        $gender = $row['gender'];
        $number = $row['phone'];
        $address = $row['address'];
        $location = $row['location'];
        $problem = $row['problem'];
        $image=$row['image'];
    } else {
        echo "User not found";
        exit;
    }
} else {
    echo "User ID not in URL";
    exit;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../booking_type.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Patient Details</title>
    <style>
    .button {
        text-align: center;
    }

    .submitbtn {
        display: inline-block;
        padding: 10px 10px;
         width:70%;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
    }
    .inputcontainer img{
        height:100px;
        width:100px;
    }
    </style>
</head>
<body>

    <div class="body">
        <form action="" method="post">
            <div class="container">
                <div class="labelcontainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="name" id="name" value="<?= $name ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="email">Email</label>
                </div>
                <div class="inputcontainer">
                    <input type="email" name="email" id="email" value="<?= $email ?>">
                </div>
</div>
                <div class="container">
                <div class="labelcontainer">
                    <label for="email">Age</label>
                </div>
                <div class="inputcontainer">
                    <input type="number" name="age" id="age"  value="<?= $age ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="email">Gender</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="gender" id="gender" value="<?= $gender ?>">
                  
                </div>
               </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="number">Mobile Number</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="number" id="number"  value="<?= $number ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="address">address</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="address" id="address" cols="30" rows="5"><?= $address ?></textarea>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="location">Location</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="location" id="location"  value="<?= $location?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Dental Problem Description</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="problem" id="problem" cols="30" rows="5" ><?= $problem ?></textarea>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Teeth  Image</label>
                </div>
                <div class="inputcontainer">
                   <img src="../uploads/<?= $image?>" alt="">
                  
                </div>
            </div>
            <div class="button">
            <a href="appointmentDate.php?id=<?=$id?>"class="submitbtn">OK</a>

            </div>
        </form>
    </div>
</body>
</html>
