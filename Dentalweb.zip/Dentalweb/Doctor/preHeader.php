<?php 
include('connection.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../preHeader.css">
 <style> 
  .headerform{
    background:#126983;
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
}
.headerform div{
    color:white;
    padding:5px;
    font-size:15px;
    margin:5px 0px;
    line-height:25px;
    
}
.location{
    display:flex;
    justify-content:space-between;
}
img{
    height:100px;
    width:100px;
}
        
        
        </style>
</head>
<body>
<div class="headerform">
                <img src="ourdental.png" alt="">
                <div class="location">
                    <div>162, Poonamallee High Rd, Velappanchavadi,
                        <BR> Chennai, Tamil Nadu 600077</div>
                    <div>+91 893999424,<br>+044 26801583</div>
</div></div>
</body>
</html>