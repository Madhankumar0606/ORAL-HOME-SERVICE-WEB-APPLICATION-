<?php
session_start();
include('function.php');
include('header2.html');

if (!isset($_SESSION['auth_user']['user_id'])) {
    header('location: login.php'); // Redirect to the login page if the user is not logged in
    exit();
}
else if (isset($_POST['updateprofile'])) {
    // Check if the fields exist in the POST data before using them
    $user_id = $_SESSION['auth_user']['user_id'];
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $specialist = mysqli_real_escape_string($con, $_POST['specialist']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);

    // Use double quotes to specify column names and their new values in the SQL query
    $update_query = "UPDATE doctor_register SET name ='$name', email='$email', phone='$phone', age='$age',
        gender='$gender',specialist='$specialist',cpassword='$cpassword', password='$password' WHERE id = $user_id";

    $update_query_run = mysqli_query($con, $update_query);

    if ($update_query_run) {
        echo '<script>alert("Update successful");</script>';
      #  echo '<script>window.location.href = "doctorprofile.php";</script>';
    } else {
        echo "Update failed: " . mysqli_error($con); // Display the error message for debugging
    }
}
$user_id = $_SESSION['auth_user']['user_id'];

// Query the database to get the user's details
$user_query = "SELECT * FROM doctor_register WHERE id = $user_id";
$user_query_run = mysqli_query($con, $user_query);

if (!$user_query_run) {
    die("Database query error: " . mysqli_error($con));
}

if ($user_query_run && $user_data = mysqli_fetch_assoc($user_query_run)) {
    // User data is available, you can display and edit it
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../editProfile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Add your styles here */
    </style>
</head>

<body>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="editProfile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Add your styles here */
    </style>
</head>

<body>
    <div class="ProfileBox">
        <div class="editProfile">
          
        </div>
        <form action="" method="post">
        
            <div class="container">
            <h3 style="margin: 10px;">Edit Profile</h3>
                <div class="labelContainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="name" id="name" value="<?= htmlspecialchars($user_data['name']) ?>">
                </div>

                <!-- Add similar sections for other fields like email, age, gender, phone, and password -->
                <div class="labelContainer">
                    <label for="email">Email</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="email" id="email" value="<?= htmlspecialchars($user_data['email']) ?>">
                </div>

                <div class="labelContainer">
                    <label for="age">Age</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="age" id="age" value="<?= htmlspecialchars($user_data['age']) ?>">
                </div>

                <div class="labelContainer">
                    <label for="gender">Gender</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="gender" id="gender" value="<?= htmlspecialchars($user_data['gender']) ?>">
                </div>

                <div class="labelContainer">
                    <label for="phone">Phone Number</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($user_data['phone']) ?>">
                </div>
                
                <div class="labelContainer">
    <label for="specialist">Specialist</label>
</div>
<div class="inputContainer">
    <input type="text" name="specialist" id="specialist" value="<?= htmlspecialchars($user_data['specialist']) ?>">
</div>

                <div class="labelContainer">
                    <label for="password">Password</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="password" id="password" value="<?= htmlspecialchars($user_data['password']) ?>" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
           title="Password must contain at least 8 characters, including at least one digit, one lowercase letter, and one uppercase letter.">
                </div>
                <div class="labelContainer">
                    <label for="password">Password</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="cpassword" id="cpassword" value="<?= htmlspecialchars($user_data['cpassword']) ?>"pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
           title="Password must contain at least 8 characters, including at least one digit, one lowercase letter, and one uppercase letter.">
                </div>

                <button type="submit" name="updateprofile" class="update">Update Profile</button>
            </div>
        </form>
    </div>
</body>

</html>




<?php
} 
?>
