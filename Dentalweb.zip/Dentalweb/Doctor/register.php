<?php
session_start();
include('connection.php');

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);
    $specialist = mysqli_real_escape_string($con, $_POST['specialist']);
    $duplicate = mysqli_query($con, "SELECT * FROM doctor_register  WHERE email='$email'");

    if (mysqli_num_rows($duplicate) > 0) {
        echo "<script>alert('Email is already taken');</script>";
        header('location:login_register.php');
    } else {
        if ($password == $cpassword) {
            $insert_query = "INSERT INTO doctor_register (name, email, phone,age,gender, password, cpassword,specialist) VALUES ('$name', '$email', '$phone','$age','$gender', '$password', '$cpassword','$specialist')";
            $insert_query_run = mysqli_query($con, $insert_query);

            if ($insert_query_run) {
                $_SESSION['message2'] = "Register Successfully. Please Login";
                header('location: login.php');
            } else {
                $_SESSION['message2'] = "Something went Wrong";
                header('location:login.php');
            }
        }
    }
}



else if(isset($_POST['login']))
{
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    $login_query = "SELECT * FROM doctor_register WHERE email='$email' AND password='$password'";
    $login_query_run = mysqli_query($con, $login_query);
    $userId=$_SESSION['auth_user']['user_id'];
    if ($login_query_run) {
        if (mysqli_num_rows($login_query_run) > 0) {
            $_SESSION['auth'] = true;

            $userdata = mysqli_fetch_array($login_query_run);
            $userid = $userdata['id'];
            $username = $userdata['name'];
            $useremail = $userdata['email'];
            $role_as = $userdata['role_as'];
            $_SESSION['auth_user'] = [
                'user_id' => $userid,
                'name' => $username,
                'email' => $email
            ];

            $_SESSION['role_as'] = $role_as;
            if ($role_as == 1) {
                $_SESSION['message'] = "Welcome to the Dashboard";
              // echo '<script>alert("Passwords do not match");</script>';
               
                header('location: ../admin/adminpage.php');
            } else {
                 $_SESSION['message'] = "Welcome ";
              // echo "<script>alert('Welcome Shop Now');</script>";
                header('location:PatientAppointment.php');
            }
        } else {
            $_SESSION['message'] = "Invalid Credentials";
         //  echo '<script>alert("Invalid Credentials");</script>';
            header('location: login.php');
        }
    } else {
        $_SESSION['message'] = "Error in the SQL query";
       // echo '<script>alert("Error in the SQL query");</script>';
        header('location: login.php');
    }
}







?>




