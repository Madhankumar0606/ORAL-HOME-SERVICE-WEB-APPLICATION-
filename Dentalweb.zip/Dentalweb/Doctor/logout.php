<?php
session_start(); // Start the session

if (isset($_SESSION['auth_user'])) {
    // If the user is logged in, unset or destroy the session variables
    unset($_SESSION['auth_user']);
    session_destroy();
}

// Redirect the user to the login page or any other desired page
header('location:login.php');
?>
