<?php
session_start();
include('header2.html');
include('connection.php');

?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   <link rel="stylesheet" href="./login_register.css">
   
   <style>
       
      

    </style>
</head>
<body>
    <div class="mainbody">
    <div class="container">
        <h2>Login</h2>
        <div class="message">
        <?php  if(isset($_SESSION['message']))
        {
            ?>
        
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Hello </strong><?=$_SESSION['message'];?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php
          unset($_SESSION['message']);
        }
        ?>
        </div>
        <form action="register.php" method="post">
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            
           
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="forgot">
                <div class="remember">
                    <input type="checkbox">Remember me</div>
                    <div class="forgotpassword">
                        <h6>forgot Password?</h6>
    </div>
    </div>
            <div class="form-group">
                <input type="submit" name="login"value="Login">
            </div>
        </form>
    </div>




  <div class="container">
        <h2> Doctor Registration Form</h2>
        <div class="message2">
        <?php  if(isset($_SESSION['message2']))
        {
            ?>
        
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Hello </strong><?=$_SESSION['message2'];?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php
          unset($_SESSION['message2']);
        }
        ?>
        </div>
      <form action="register.php" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Mobile Number</label>
                <input type="text" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="phone">Age</label>
                <input type="text" id="age" name="age" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <input type="text" id="gender" name="gender" required>
            </div>
            <div class="form-group">
                <label for="specialist">Specialist</label>
                <input type="text" id="specialist" name="specialist" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
           title="Password must contain at least 8 characters, including at least one digit, one lowercase letter, and one uppercase letter." required>
            </div>
            <div class="form-group">
                <label for="cpassword"> Confirm Password</label>
                <input type="password" id="cpassword" name="cpassword" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
           title="Password must contain at least 8 characters, including at least one digit, one lowercase letter, and one uppercase letter."required>
            </div>
            <div class="form-group">
               
                <input type="submit" name="register"value="Register">
            </div>
        </form>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>
</html>