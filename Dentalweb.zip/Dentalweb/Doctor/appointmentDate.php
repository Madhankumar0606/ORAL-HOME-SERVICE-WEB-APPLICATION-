<?php
session_start();
include('header2.html');
include('connection.php');
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location: login.php');
    exit(); // Stop further execution of the script
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doc_id = $_SESSION['auth_user']['user_id'];
    // Check if the date and time are set in the POST data
    if (isset($_POST['date']) && isset($_POST['time'])) {
        $selectedDate = $_POST['date'];
        $selectedTime = $_POST['time'];

        // Assuming you have a session started
        if (isset($_GET['id'])) {
            $userId = intval($_GET['id']); // Use intval to sanitize and validate the user ID

            // Prepared statement for the UPDATE query
            $updateDateQuery = "UPDATE appointment SET appointmentDate = ?, appointmentTime = ?, doctor_id = ? WHERE id = ?";
            $stmt = mysqli_prepare($con, $updateDateQuery);
            mysqli_stmt_bind_param($stmt, 'ssii', $selectedDate, $selectedTime, $doc_id, $userId);

            $updateDateQueryRun = mysqli_stmt_execute($stmt);

            if ($updateDateQueryRun) {
                // Update successful
                echo '<script>alert("Update date successfully!");</script>';
                echo '<script>window.location.href = "report.php";</script>';
            } else {
                // Update failed
                echo "Error: " . mysqli_error($con);
            }

            mysqli_stmt_close($stmt);
        } else {
            // User ID not set in URL
            echo "User ID not set in URL!";
        }
    } else {
        // Date or time not set in POST data
        echo "Date or time not set!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Date</title>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

        .container {
            margin: 50px auto;
            width: 80%;
        }

        .date {
            display: flex;
            justify-content:center;
            margin-bottom: 20px;
        }

        input {
            padding: 10px;
            margin-bottom: 10px;
        }

        .button {
            text-align: center;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #126983;
            color: white;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="post">
            <div class="date">
                <input type="date" name="date" id="date">
                <input type="time" name="time" id="time">
            </div>
            <div class="button">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
</body>
</html>
