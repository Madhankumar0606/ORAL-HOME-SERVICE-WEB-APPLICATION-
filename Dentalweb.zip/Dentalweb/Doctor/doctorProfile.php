<?php
session_start();
include('header2.html');
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location:login.php');
    exit(); // Stop further execution of the script
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        :root{
    --button:#126983;
    --title:rgb(0, 99, 160);
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');
*
{
    margin:0%;
    padding:0%;
}

@media only screen and (max-width: 768px){
    html,
    body{
    width:100%;
    overflow-x:hidden;
    }
    }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .body {
            background-color: #f4f4f4;
            padding: 20px;
        }

        .row {
            margin-bottom: 20px;
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .profile {
            display: flex;
            align-items: center;
            font-size: 18px;
        }

        .profile i {
            margin-right: 10px;
            font-size: 24px;
        }
        .profile a{
            text-decoration:none;
            color:black;
        }

        .profile:hover {
            background-color: #f0f0f0;
        }
        .boxContainer{
    

    display: flex;
    justify-content: center;
    background-color: #f4f4f4;
    padding:10px;
    
}
.user-profile{
    font-size: 20px;
}
    </style>
    <title>Profile</title>
</head>

<body>
<div class="body">
<div class="boxContainer">
<span class="iconbox"><i class="fa fa-user"></i></span>
                
                    <div class="user-profile">
                        <?php
                        if (isset($_SESSION['auth_user']['name'])) {
                            echo 'Welcome, ' . $_SESSION['auth_user']['name'];
                        } else {
                            echo 'Guest'; // You can customize the message for users who are not logged in
                        }
                        ?>
                    </div>
                    </div>
        <div class="container">
            <div class="row">
                <div class="profile">
                 <a href="editprofile_doctor.php">   <i class="fa fa-edit"></i>Edit Profile</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="viewAppointmentDate.php">    <i class="fa fa-medkit"></i>View Patient Appointment Date</a>
                </div>
            </div>
           <!-- <div class="row">
                <div class="profile">
                <a href="">     <i class="fa fa-question-circle"></i>Rate Us</a>
                </div>
            </div>-->
            <div class="row">
                <div class="profile">
                <a href="Terms & Conditions.php">    <i class="fa fa-question-circle"></i>Terms & Conditions</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="privacy.php">    <i class="fa fa-question-circle"></i>Privacy Policy</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="logout.php"> <i class="fa fa-sign-out"></i>Log Out</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
