<?php
session_start();
include('header2.html');
include('connection.php');
include('function.php');
$userId = $_SESSION['auth_user']['user_id'];
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location: login.php');
    exit(); // Stop further execution of the script
}

function getAppointmentDoctor()
{
    global $con, $userId;
    $appoint_query = "SELECT * FROM appointment WHERE doctor_id=$userId";
    $appoint_query_run = mysqli_query($con, $appoint_query);

    $appointments = [];
    while ($row = mysqli_fetch_assoc($appoint_query_run)) {
        $appointments[] = $row;
    }

    return $appointments;
}

// Check if the form is submitted for accepting or declining an appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['acceptAppointment'])) {
        $acceptedAppointmentId = $_POST['acceptedAppointmentId'];

        // Update the appointment_status to 'accepted'
        $updateQuery = "UPDATE appointment SET appointment_status = 'accepted' WHERE id = $acceptedAppointmentId";
        $updateQueryRun = mysqli_query($con, $updateQuery);

        if ($updateQueryRun) {
            echo '<script>alert("Appointment accepted successfully");</script>';
            echo '<script>window.location.href = "viewPatient.php";</script>';
        } else {
            echo "Error accepting appointment: " . mysqli_error($con);
        }
    } elseif (isset($_POST['declineAppointment'])) {
        $declinedAppointmentId = $_POST['declinedAppointmentId'];

        // Update the appointment_status to 'declined'
        $updateQuery = "UPDATE appointment SET appointment_status = 'declined' WHERE id = $declinedAppointmentId";
        $updateQueryRun = mysqli_query($con, $updateQuery);

        if ($updateQueryRun) {
            echo '<script>alert("Appointment declined successfully");</script>';
            echo '<script>window.location.href = "your_decline_page.php";</script>';
        } else {
            echo "Error declining appointment: " . mysqli_error($con);
        }
    }
}

$appointments = getAppointmentDoctor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="patientAccept_doctor.css">
    <title>View Appointment</title>
    <style>
        /* Your CSS styles */
    </style>
</head>
<body>
   <!-- <div class="title">
        <h3>View Patient Appointment</h3>
    </div>-->
    <section class="details">
        <?php
        if (!empty($appointments)) {
            foreach ($appointments as $item) {
                ?>
                <div class="appointmentDetails">
                    <div class="user">
                        <div class="details">
                        <div><strong>Name:</strong><span class="appointmentInfo"><?=$item['name']?></span></div>
                    <div><strong>Age:</strong><span class="appointmentInfo"><?=$item['age']?></span></div>
                    
                    <div><strong>Gender:</strong><span class="appointmentInfo"><?=$item['gender']?></span></div>
                    <div><strong>Phone:</strong><span class="appointmentInfo"><?=$item['phone']?></span></div>
                    <div><strong>Email:</strong><span class="appointmentInfo"><?=$item['email']?></span></div>
                   
                    <div><strong>Address:</strong><span class="appointmentInfo"><?=$item['address']?></span></div>
                        </div>
                        <div class="button">
                        <?php
if ($item['appointment_status'] == 'accepted') {
    if ($item['appointmentDate'] !== '0000-00-00' && $item['appointmentDate'] !== '00:00:00') {
        echo' <strong>Appointment Date:</strong><span style="color: green; font-size:20px;">' . $item['appointmentDate'] . '</span>';
        echo' <strong>Appointment Time:</strong><span style="color: green; font-size:20px;">' . $item['appointmentTime'] . '</span>';
    } else {
        echo '<p style="color: green;font-size:20px;">Accepted</p>';
    }
} elseif ($item['appointment_status'] == 'declined') {
    echo '<p style="color: red;font-size:20px;">Declined</p>';
} elseif ($item['appointment_status'] == 'completed') {
    echo '<p style="color: blue;font-size:20px;">Completed</p>';
} 

                             else {
                                ?>
                                <form action="" method="post">
                                    <input type="hidden" name="acceptedAppointmentId" value="<?= $item['id'] ?>">
                                    <button type="submit" name="acceptAppointment" class="acceptbutton" style="background-color:green;">Accept</button>
                                </form>
                                <form action="" method="post">
                                    <input type="hidden" name="declinedAppointmentId" value="<?= $item['id'] ?>">
                                    <button type="submit" name="declineAppointment" class="declinebutton" style="background-color:red;">Decline</button>
                                </form>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            ?>
            <div class="noAppointment">No appointments yet.</div>
            <?php
        }
        ?>
    </section>
</body>
</html>
