<?php
session_start();
include('header2.html');
include('connection.php');

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location: login.php');
    exit(); // Stop further execution of the script
}

function getprescription()
{
    global $con;
    $doc_id = $_SESSION['auth_user']['user_id'];
    $prescription_query = "SELECT * FROM prescription WHERE doc_id='$doc_id'";
    $prescription_query_run = mysqli_query($con, $prescription_query);

    // Check if the query was successful
    if ($prescription_query_run) {
        $prescription_data = array();
        while ($row = mysqli_fetch_assoc($prescription_query_run)) {
            $prescription_data[] = $row;
        }
        return $prescription_data;
    } else {
        // Handle the error if the query fails
        echo "Error: " . mysqli_error($con);
        return array(); // Return an empty array in case of an error
    }
}

$prescription = getprescription();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Prescription</title>
    <style>
        :root{
    --button:#126983;
    --title:rgb(0, 99, 160);
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap');
*
{
    margin:0%;
    padding:0%;
}



@media only screen and (max-width: 768px){
html,
body{
width:100%;
overflow-x:hidden;
}
}
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

      
      

        .appointmentDetails {
          
            padding: 10px;
            margin:10px 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color:white;
            
        }
        .user{
            display:flex;
            justify-content:space-between;
        }

        strong {
          
            margin: 10px;
           
            display: inline-block;
            width: 150px; 
            text-align: right;
        }

        .appointmentDetails div {
            
        }

        .date {
            font-size: 0.8em;
            color: #888;
        }

        .noAppointment {
            text-align: center;
            font-style: italic;
            color: #888;
        }

        .appointmentInfo {
            display: inline-block;
                color:rgb(0, 99, 160);
            font-weight:700px;
        }
        .box
        {
            display:flex;
            justify-content:space-between;
        }
        .title
        {
            background-color:black;
            color:white;
            padding:10px;
        }
        .viewbutton
        {
            padding: 6px 20px;
            border-radius:5px;
            color:white;
            background-color:#126983;
            border:none;
        }
        .button a{
            text-decoration:none;
        }
        @media (max-width: 767px) {
    .box
    {
        display:block;
       
    }
    strong {
  
        
        text-align:left;
    }
    .appointmentDetails {
  
        padding:0px;
        margin:10px;
       
    }
  .details{
        margin: 10px 5px;
    }
    .box1{
        display: block;
    }
    #date{
        margin-right:0;
    }

 
}
    </style>
</head>
<body>
<div class="title">
        <h3>View prescription </h3>
    </div>
    <section class="details">
        <?php
        if (!empty($prescription)) {
            foreach ($prescription as $item) {
        ?>
        <div class="appointmentDetails">
            <div class="user">
                <div class="details">
                    <div><strong>Name:</strong><span class="appointmentInfo"><?=$item['name']?></span></div>
                    <div><strong>Age:</strong><span class="appointmentInfo"><?=$item['age']?></span></div>
                    <div><strong>Gender:</strong><span class="appointmentInfo"><?=$item['gender']?></span></div>
                    <div><strong>Phone:</strong><span class="appointmentInfo"><?=$item['phone']?></span></div>
                </div>
                <div class="button">
                   <!-- <a href="PrescriptionReport_doctor.php?id=<?= $item['id'] ?>" class="viewbutton">Report</a>-->
                </div>
            </div>
        </div>
        <?php
            }
        } else {
        ?>
        <div class="noAppointment">No appointments yet.</div>
        <?php
        }
        ?>
    </section>
</body>
</html>