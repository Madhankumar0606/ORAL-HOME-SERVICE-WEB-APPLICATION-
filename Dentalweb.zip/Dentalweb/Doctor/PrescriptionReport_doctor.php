<?php
session_start();
include('header2.html');
include('connection.php');

$userId = $_SESSION['auth_user']['user_id'];
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location: login.php');
    exit(); // Stop further execution of the script
}

if (isset($_POST['submit'])) {
    $doc_id = $_SESSION['auth_user']['user_id'];
    $app_id = $_GET['id'];
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $date = mysqli_real_escape_string($con, $_POST['date']);
    $time = mysqli_real_escape_string($con, $_POST['time']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $sign = mysqli_real_escape_string($con, $_POST['sign']);

    // File details
    $prescription_image = $_FILES['prescription']['name'];
    $scan_image = $_FILES['scan']['name'];
    $prescription_temp = $_FILES['prescription']['tmp_name'];
    $scan_temp = $_FILES['scan']['tmp_name'];

    // Check if all required fields are present before inserting into the database
    if ($app_id && $name && $phone && $age && $gender && $date && $time && $description && $sign) {
        // Use prepared statements to prevent SQL injection
        $report_query = "INSERT INTO prescription (app_id, name, doc_id, phone, date, time, age, gender, detail, prescription_image, scan_image, sign) VALUES (?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($report_query);

        // Check if the statement is prepared successfully
        if ($stmt) {
            // Bind parameters
            $stmt->bind_param("ssssssssssss", $app_id, $name, $doc_id, $phone, $date, $time, $age, $gender, $description, $prescription_image, $scan_image, $sign);

            // Execute the query
            $report_query_run = $stmt->execute();

            // Check if the query was successful
            if ($report_query_run) {
                // Move uploaded files to the desired location
                move_uploaded_file($prescription_temp, "report/" . $prescription_image);
                move_uploaded_file($scan_temp, "report/" . $scan_image);

                // Update appointment status
                $update_appointment_query = "UPDATE appointment SET appointment_status = 'completed' WHERE id = $app_id";
                $update_appointment_result = mysqli_query($con, $update_appointment_query);

                if ($update_appointment_result) {
                    echo '<script>alert("Prescription submitted successfully!");</script>';
                    echo '<script>window.location.href = "patientAppointment.php";</script>';
                } else {
                    echo '<script>alert("Error updating appointment status: ' . mysqli_error($con) . '");</script>';
                }
            } else {
                echo '<script>alert("Error: ' . $stmt->error . '");</script>';
            }

            // Close the statement
            $stmt->close();
        } else {
            echo '<script>alert("Error preparing statement: ' . $con->error . '");</script>';
        }
    } else {
        echo '<script>alert("All fields are required!");</script>';
    }
}

// Close the database connection
$con->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../booking_type.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Prescription Report</title>
    <style>
     
    </style>
</head>
<body>
<div class="title">
<h3><i class="fa fa-comments"></i>Prescription Report</h3>
    </div>
    <div class="body">
        <?php 
        include('./preHeader.php');
        ?>
    <form action="" method="post" enctype="multipart/form-data">
            <div class="container">
                <div class="labelcontainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="name" id="name" required>
                </div>
            </div>
 
                <div class="container">
                    <div class="labelcontainer">
                      <label for="email">Age</label>
                    </div>
                    <div class="inputcontainer">
                        <input type="number" name="age" id="age" required>
                    </div>
                </div>
            <div class="container">
            <div class="inputcontainer">
                    <div class="gender">
                        <select name="gender" id="gender">
                        <option value="option">Select </option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        </select>
                    </div>
                 </div>
            </div>

               
            <div class="container">
                <div class="labelcontainer">
                    <label for="number">Mobile Number</label>
                </div>
                <div class="inputcontainer">
               
                <input type="text" name="phone" id="phone" required>

                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="date">Date Visited On:</label>
                </div>
                <div class="inputcontainer">
                    <input type="date" name="date" id="date" required>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="Time"> Time</label>
                </div>
                <div class="inputcontainer">
                    <input type="time" name="Time" id="Time" required>
                </div>
            </div>

            <div class="container">
                <div class="labelcontainer">
                    <label for="description">Detail Description About the Patient Symptom</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="description" id="description" cols="30" rows="5" required></textarea>
                </div>
            </div>
            <div class="container">
        <div class="labelcontainer">
            <label for="scan">X-Ray/ Scan Photo:</label>
        </div>
        <div class="inputcontainer">
            <input type="file" name="scan" class="scan">
        </div>
    </div>
         
            <div class="container">
                <div class="labelcontainer">
                    <label for="scan">Prescription Photo</label>
                </div>
                <div class="inputcontainer">
                <input type="file" name="prescription" class="prescription">

                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="sign">E-signature</label>
                </div>
                <div class="inputcontainer">
                <input type="text" name="sign" class="sign">

                </div>
</div>
            <div class="button">
                <button type="submit" class="submitbtn" name="submit">Submit</button>
            </div>
        </form>
    </div>
</body>
</html>