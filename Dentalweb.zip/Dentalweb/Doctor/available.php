<?php
session_start();
include('connection.php');
include('header2.html');

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['submit'])) {
    $status = $_POST['status'];
    $userId=$_SESSION['auth_user']['user_id'];

    $status_query = "UPDATE doctor_register SET status = '$status' WHERE id = $userId";


    $status_query_run = mysqli_query($con, $status_query);

    if ($status_query_run) {
        header('Location:PatientAppointment.php');
    } else {
        echo "Error updating status: " . mysqli_error($con);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="your-styles.css"> <!-- Link to your custom styles or add styles directly here -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        h3 {
            color:#126983;
        }

        .centerbox {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .appointtype {
            text-align: center;
            margin-top: 20px;
        }

        .book {
            background-color: #f2f2f2;
            padding: 10px;
            border-radius: 5px;
        }

        input[type="radio"] {
            margin: 5px;
        }

        .btn {
            margin-top: 15px;
        }

        .submit {
            background-color:#126983;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .submit:hover {
            background-color:black;
        }
    </style>
    <title>Book Appointment</title>
</head>
<body>
    <header>
        <h3>Welcome to Our Dental Clinic, <span><?php echo $_SESSION['auth_user']['name']; ?></span></h3>
    </header>
    <div class="centerbox">
        <div class="appointtype">
            <div class="book">
                <form action="" method="post">
                    <input type="radio" name="status" id="available" value="available">Available
                    <input type="radio" name="status" id="unavailable" value="unavailable">Unavailable
                    <input type="radio" name="status" id="holiday" value="holiday">Holiday
                    <div class="btn">
                        <button type="submit" name="submit" class="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

