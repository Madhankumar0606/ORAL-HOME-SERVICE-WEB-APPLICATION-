
<?php
session_start();
include('header2.html');
include('connection.php');
include('function.php');
$userId = $_SESSION['auth_user']['user_id'];

function getAppointmentDoctor()
{
    global $con, $userId; // Added $userId
    $appoint_query = "SELECT * FROM appointment WHERE doctor_id = $userId AND appointment_status = 'declined'"; // Fixed the comparison
    $appoint_query_run = mysqli_query($con, $appoint_query);

    // Fetch the result as an associative array
    $appointments = [];
    while ($row = mysqli_fetch_assoc($appoint_query_run)) {
        $appointments[] = $row;
    }

    return $appointments;
}


$appointments = getAppointmentDoctor();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointment</title>
    <style>
             *
        {
            margin:0;
            padding:0;
            font-family: 'Inter', sans-serif;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

      
      

        .appointmentDetails {
          
            padding: 10px;
            margin:10px 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color:white;
            
        }
        .user{
            display:flex;
            justify-content:space-between;
        }

        strong {
          
            margin: 10px;
           
            display: inline-block;
            width: 150px; 
            text-align: right;
        }

        .appointmentDetails div {
            
        }

        .date {
            font-size: 0.8em;
            color: #888;
        }

        .noAppointment {
            text-align: center;
            font-style: italic;
            color: #888;
        }

        .appointmentInfo {
            display: inline-block;
                color:rgb(0, 99, 160);
            font-weight:700px;
        }
        .box
        {
            display:flex;
            justify-content:space-between;
        }
        .title
        {
            background-color:black;
            color:white;
            padding:10px;
        }
        .viewbutton
        {
            padding: 6px 20px;
            border-radius:5px;
            color:white;
            background-color:#126983;
            border:none;
        }
        .button a{
            text-decoration:none;
        }
    </style>
</head>
<body>
    <div class="title">
        <h3>Declined  Patient Appointment</h3>
    </div>
    <section class="details">
        <?php
        if (!empty($appointments)) { // Check if appointments array is not empty
            foreach ($appointments as $item) {
                ?>
                <div class="appointmentDetails">
                    <div class="user">
                        <div class="details">
                        <div><strong>Name:</strong><span class="appointmentInfo"><?=$item['name']?></span></div>
                    <div><strong>Age:</strong><span class="appointmentInfo"><?=$item['age']?></span></div>
                    
                    <div><strong>Gender:</strong><span class="appointmentInfo"><?=$item['gender']?></span></div>
                    <div><strong>Phone:</strong><span class="appointmentInfo"><?=$item['phone']?></span></div>
                    <div><strong>Email:</strong><span class="appointmentInfo"><?=$item['email']?></span></div>
                   
                    <div><strong>Address:</strong><span class="appointmentInfo"><?=$item['address']?></span></div>
                  
                
                        </div>
                        <div class="button">
                            <?php if ($item['appointmentDate'] !== '0000-00-00') { ?>
                                <a href="" class="viewbutton" style="background-color:green;"><?= $item['appointmentDate'] ?></a>
                            <?php } ?>
                            <a href="viewPatientDetails.php?id=<?= $item['id'] ?>" class="viewbutton">View</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            ?>
            <div class="noAppointment">No appointments yet.</div>
            <?php
        }
        ?>
    </section>
</body>
</html>
