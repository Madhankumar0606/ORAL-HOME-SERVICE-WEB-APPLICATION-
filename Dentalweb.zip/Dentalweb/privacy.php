
<?php
include('header.html');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <STYle>
    body {
            font-family: 'Arial', sans-serif;
        
            
        }
        .body{
            margin:10px;
            padding:10px;
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        header h1 {
            color: #333;
        }

        section {
            margin-bottom: 30px;
        }

        h2 {
            color: #333;
            border-bottom: 2px solid #333;
            padding-bottom: 5px;
            margin-bottom: 15px;
        }

        h3 {
            color: #333;
            margin-top: 15px;
        }

        ul {
            margin-bottom: 15px;
            list-style-type: square;
        }

        p {
            color: #555;
        }
   </STYle>
</head>

<body>
<div class="body">
    <header>
        <h1>Privacy Policy</h1>
      
    </header>

    <section>
        <h2>Information We Collect</h2>

        <h3>Personal Information:</h3>
        <p>We may collect personal information, such as:</p>
        <ul>
            <li>Full name</li>
            <li>Contact information (email address, phone number)</li>
            <li>Date of birth</li>
            <li>Medical history</li>
            <li>Insurance information</li>
        </ul>

        <h3>Non-Personal Information:</h3>
        <p>We may also collect non-personal information, such as:</p>
        <ul>
            <li>Browser type</li>
            <li>Device type</li>
            <li>IP address</li>
            <li>Cookies (for more details, see our Cookie Policy)</li>
        </ul>
    </section>

    <section>
        <h2>How We Use Your Information</h2>
        <p>We use your information for various purposes, including:</p>
        <ul>
            <li>Scheduling and managing appointments</li>
            <li>Sending appointment reminders</li>
            <li>Processing payments and insurance claims</li>
            <li>Improving our services and website</li>
            <li>Communicating with you about promotions or updates</li>
        </ul>
    </section>

    <section>
        <h2>Information Sharing</h2>
        <p>We do not sell, trade, or otherwise transfer your personal information to outside parties. We may share your information with trusted third parties who assist us in operating our website, conducting our business, or servicing you.</p>
    </section>

    <section>
        <h2>Security</h2>
        <p>We implement a variety of security measures to maintain the safety of your personal information. We use industry-standard encryption to protect sensitive information transmitted online.</p>
    </section>

    <section>
        <h2>Your Choices</h2>
        <p>You have the right to:</p>
        <ul>
            <li>Review and correct your personal information</li>
            <li>Opt-out of marketing communications</li>
            <li>Request deletion of your account (subject to legal obligations)</li>
        </ul>
    </section>

    <section>
        <h2>Changes to This Privacy Policy</h2>
        <p>We may update this Privacy Policy from time to time. The date of the latest revision will be indicated at the top of the page.</p>
    </section>

    <section>
        <h2>Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us at [contact email/phone].</p>
    </section>
    </div>
</body>

</html>
