<?php
include('function.php');
include('connection.php');
include('header.html');

if (isset($_GET['query'])) {
    $search_query = mysqli_real_escape_string($con, $_GET['query']);
    $search_query = '%' . $search_query . '%';

    $search_result_query = "SELECT * FROM testtype WHERE name LIKE ?";
    $stmt = mysqli_prepare($con, $search_result_query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $search_query);
        mysqli_stmt_execute($stmt);
        $search_result = mysqli_stmt_get_result($stmt);

        $products = mysqli_fetch_all($search_result, MYSQLI_ASSOC);

        mysqli_stmt_close($stmt);
    } else {
        echo "Error in preparing statement: " . mysqli_error($con);
    }
} else {
    $testType = getAllActive("testtype");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="labTest.css">
    <title>Lab Test</title>
    <style>

    </style>
</head>

<body>
    <section class="body">
        <form action="" method="get">
            <input type="text" id="search" name="query" placeholder="Search Lab Tests,Packages">
            <button type="submit">Search</button>
        </form>
    </section>
    <section class="test">
        <div class="testtype">
            <div class="category-list">
                <?php
                if (!empty($products)) {
                    foreach ($products as $product) {
                        ?>
                        <div class="test-item">
                            <div class="category-image">
                                <img src="uploads/<?= $product['image'] ?>" alt="Category Image" width="100px"
                                     height="100px">
                            </div>
                            <a class="title"
                               href="availableTest.php?testtype=<?= urlencode($product['slug']); ?>">
                                <?= $product['name']; ?>
                            </a>
                        </div>
                        <?php
                    }
                } else {
                    echo '<div class="noresult">';
                    echo "No records Found";
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </section>
</body>

</html>
