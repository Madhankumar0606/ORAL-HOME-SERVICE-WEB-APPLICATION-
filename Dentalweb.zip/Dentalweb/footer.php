<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
      footer {
    background-color: #126983;
    color: #fff;
    text-align: center;
    padding: 20px 0;
    position: relative;
    bottom: 0;
    width: 100%;
    margin-top:100px;
}

        footer p {
            margin: 0;
        }
   </style>
</head>
<body>
<footer>
        <p>Contact Oral Home to schedule your appointment and experience exceptional dental care.</p>
        <p>Phone:+91 893999424,+044 26801583| websitesaveetha@gmail.com</p>
    </footer>

</body>
</html>