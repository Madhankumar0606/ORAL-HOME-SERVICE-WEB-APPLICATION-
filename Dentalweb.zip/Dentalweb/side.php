<!DOCTYPE html>
<!-- Coding By CodingNepal - codingnepalweb.com -->
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> Admin Dashboard </title>
    <link rel="stylesheet" href="side.css" />
    <!-- Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" />
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
  </head>
  <body>
    <nav class="sidebar">
      <a href="#" class="logo">Wedding</a>

      
          <div class="menu-content">
        <ul class="menu-items">
         

          <li class="item">
            <a href="#">Dashboard</a>
          </li><li class="item">
            <a href="#">First from data</a>
          </li>
         
          <li class="item">
            <div class="submenu-item">
              <span>Site Settings</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
              Site Settings
              </div>
              <li class="item">
                <a href="#"> Update Logo & Favicon</a>
              </li>
              <li class="item">
                <a href="#">Update Home Banner</a>
              </li>
              <li class="item">
                <a href="#">Update Watermark</a>
              </li>
			  <li class="item">
                <a href="#">Update Field Enable / Disable</a>
              </li>
			  <li class="item">
                <a href="#">Update Menu Item Enable / Disable</a>
              </li>
			  <li class="item">
                <a href="#">Update Prefix Id</a>
              </li>			
			  <li class="item">
                <a href="#">Update Email Setting</a>
              </li>			
			  <li class="item">
                <a href="#">Update Basic Site Update</a>
              </li>
			  <li class="item">
                <a href="#">Update Site Configuration</a>
              </li> 
			  <li class="item">
                <a href="#">Update /add Analytics Code</a>
              </li> 
			  <li class="item">
                <a href="#">Change Password</a>
              </li>
			  <li class="item">
                <a href="#"> Update Social Icon Link</a>
              </li>
			  <li class="item">
                <a href="#"> Android Banner Settings</a>
              </li>
            </ul>
          </li>
		            <li class="item">
            <div class="submenu-item">
              <span> Franchisee</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                 Franchisee
              </div>
              <li class="item">
                <a href="#">All Franchisee</a>
              </li>
              <li class="item">
                <a href="#">Frenchise Payment Pending</a>
              </li>
			  <li class="item">
                <a href="#">Frenchisee Payment Approved</a>
              </li>
			    </ul>
          </li>		        
		  <li class="item">
            <div class="submenu-item">
              <span> Staff</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                 Staff
              </div>
              <li class="item">
                <a href="#">All Staff</a>
              </li>
              <li class="item">
                <a href="#">Add Staff</a>
              </li>
			
			    </ul>
          </li>
          <li class="item">
            <div class="submenu-item">
              <span>Add new title</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
              Add new title
              </div>
              <li class="item">
                <a href="#">Add Religion</a>
              </li>
              <li class="item">
                <a href="#">Add Caste</a>
              </li>
              <li class="item">
                <a href="#">Add Subcaste</a>
              </li>
              <li class="item">
                <a href="#">Add City</a>
              </li>
              <li class="item">
                <a href="#">Add Country</a>
              </li>
              <li class="item">
                <a href="#">Add State</a>
              </li>
              <li class="item">
                <a href="#">Add Occuption</a>
              </li>
              <li class="item">
                <a href="#">Add Education</a>
              </li>
              <li class="item">
                <a href="#">Add Mother Tongue</a>
              </li>
              <li class="item">
                <a href="#">Add Star</a>
              </li>
              <li class="item">
                <a href="#">Add Rasi</a>
              </li>
              <li class="item">
                <a href="#">Add Annual Income</a>
              </li>
              <li class="item">
                <a href="#">Add Dosh</a>
              </li>
              
            </ul>
          </li>
                <li class="item">
            <div class="submenu-item">
              <span> Members</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                 Members
              </div>
              <li class="item">
                <a href="#">Add Members</a>
              </li>
              <li class="item">
			  <form action="viewmember.php" method="post">
                <a href="#">All Members</a></form>
              </li>
			  <li class="item">
                <a href="#">Active To Paid Members</a>
              </li>
			  <li class="item">
                <a href="#">Renew Memebership</a>
              </li> 
			  <li class="item">
                <a href="#">Change Memebership plan</a>
              </li>
			  <li class="item">
                <a href="#">Feature Profile</a>
              </li>
			
			    </ul>
          </li>
		  <li class="item">
            <div class="submenu-item">
              <span>User Activity</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
               User Activity
              </div>
              <li class="item">
                <a href="#">Express Interest</a>
              </li>
              <li class="item">
                <a href="#">All Message</a>
              </li>
			  <li class="item">
                <a href="#">Viewed Profile</a>
              </li>
			  <li class="item">
                <a href="#">Block Profile</a>
              </li> 
			  <li class="item">
                <a href="#">Shortlisted Profile</a>
              </li>
			  <li class="item">
                <a href="#">Photo Password Request</a>
              </li>               </ul></li>
			  <li class="item">
            <div class="submenu-item">
              <span>Approvals</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>
            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
              Approvals
              </div>
              <li class="item">
                <a href="#">About Me Approval</a>
              </li>
              <li class="item">
                <a href="#">Partner Expectation Approval</a>
              </li>
			  <li class="item">
                <a href="#">Aadhaar Card Approval</a>
              </li>
			  <li class="item">
                <a href="#">Success Story Approval</a>
              </li> 
			  <li class="item">
                <a href="#">Horoscope Approval</a>
              </li>
		  <li class="item">
                <a href="#">Photo 1 Approval</a>
              </li>			 
			  <li class="item">
                <a href="#">Photo 2 Approval</a>
              </li>			  
			  <li class="item">
                <a href="#">Photo 3 Approval</a>
              </li>
			<li class="item">
                <a href="#">Photo 4 Approval</a>
              </li>
			<li class="item">
                <a href="#">Photo 5 Approval</a>
              </li>
			<li class="item">
                <a href="#">Photo 6 Approval</a>
              </li>
			
			    </ul>
          </li>
            <li class="item">
            <div class="submenu-item">
              <span> Memebership plan</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                 Memebership plan
              </div>
              <li class="item">
                <a href="#">Add Memebership plan</a>
              </li>
              <li class="item">
                <a href="#">Membership Plan List</a>
              </li>
			
			    </ul>
          </li>
		  <li class="item">
            <div class="submenu-item">
              <span> Match Making</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                 Match Making
              </div>
              <li class="item">
                <a href="#">Profile Match Making</a>
              </li>
              
			
			    </ul>
          </li>
		  <li class="item">
            <div class="submenu-item">
              <span> Advertise</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                 Advertise
              </div>
              <li class="item">
                <a href="#">Advertisement</a>
              </li>
              
			
			    </ul>
          </li> 
		  <li class="item">
            <div class="submenu-item">
              <span> Content Management</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                Content Management
              </div>
              <li class="item">
                <a href="#">CMS Pages</a>
              </li>
              
			
			    </ul>
          </li>
		  	  <li class="item">
            <div class="submenu-item">
              <span> Email Template</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
                 Email Template
              </div>
              <li class="item">
                <a href="#"> Add new Email Template</a>
              </li>
			  <li class="item">
                <a href="#"> All Email Template</a>
              </li>
              
              
			
			    </ul>
          </li> 
		  <li class="item">
            <div class="submenu-item">
              <span>Payment Option</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
              Payment Option
              </div>
              <li class="item">
                <a href="#"> Manage  Payment Option</a>
              </li>
			 
              
			
			    </ul>
          </li> 
		  <li class="item">
            <div class="submenu-item">
              <span>Member Report</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
              Member Report
              </div>
              <li class="item">
                <a href="#">Export Member to Excel file</a>
              </li>
			  <li class="item">
                <a href="#">Sales Report</a>
              </li>
			 </ul>
          </li>
		  <li class="item">
            <div class="submenu-item">
              <span>Contact Us details</span>
            
            </div>
			</li>
			 <li class="item">
            <div class="submenu-item">
              <span>Send Email</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
             Send Email
              </div>
              
			  <li class="item">
                <a href="#">Send Email To Members</a>
              </li>
			 </ul>
          </li>
		   <li class="item">
            <div class="submenu-item">
              <span>Database Operation</span>
              <i class="fa-solid fa-chevron-right"></i>
            </div>

            <ul class="menu-items submenu">
              <div class="menu-title">
                <i class="fa-solid fa-chevron-left"></i>
            Database Operation
              </div>
              
			  <li class="item">
                <a href="#">Database Backup</a>
              </li>
			 </ul>
          </li>

        </ul>
      </div>
    </nav>

    <nav class="navbar">
      <i class="fa-solid fa-bars" id="sidebar-close"></i>
    </nav>

    <main class="main">

	
	    
    </main>

    <script>
	const sidebar = document.querySelector(".sidebar");
const sidebarClose = document.querySelector("#sidebar-close");
const menu = document.querySelector(".menu-content");
const menuItems = document.querySelectorAll(".submenu-item");
const subMenuTitles = document.querySelectorAll(".submenu .menu-title");

sidebarClose.addEventListener("click", () => sidebar.classList.toggle("close"));

menuItems.forEach((item, index) => {
  item.addEventListener("click", () => {
    menu.classList.add("submenu-active");
    item.classList.add("show-submenu");
    menuItems.forEach((item2, index2) => {
      if (index !== index2) {
        item2.classList.remove("show-submenu");
      }
    });
  });
});

subMenuTitles.forEach((title) => {
  title.addEventListener("click", () => {
    menu.classList.remove("submenu-active");
  });
});
	
	
	
	</script>
  </body>
</html>