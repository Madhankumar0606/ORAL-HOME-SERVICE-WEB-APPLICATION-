<?php
include('header.html');
include('function.php');
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location: login_register.php');
    exit(); // Stop further execution of the script
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="view_appointment.css">
    <title> Appointment</title>
    <style>
.status{
    margin-left:180%;
    color:white;
            background:green;
            padding:10px 5px;
            border-radius:5px;

}
    </style>
</head>
<body>
<div class="title">
<h3>View Appointment</h3>
    </div>
  
    <section class="details">
     
        <?php
        $appointments = getAppointment();
        if (mysqli_num_rows($appointments) > 0) {
            foreach ($appointments as $item) {
                ?>
                <div class="appointmentDetails">
                <div class="box">
                     <?php
                         if ($item['appointment_status'] !== "completed")         {

if ($item['appointmentDate'] !== "0000-00-00" && $item['appointmentTime'] !== '00:00:00') {
    echo '<div><strong>Appointment Date</strong><span class="appointmentInfo datetime">' . $item['appointmentDate'] . '</span></div>';
    echo '<div><strong>Appointment time</strong><span class="appointmentInfo datetime">' . $item['appointmentTime'] . '</span></div>';
}
                         }
elseif ($item['appointment_status'] == "completed") {
    // Display status only if the status is "completed"
    echo '<div><strong></strong><span class="appointmentInfo status">' . $item['appointment_status'] . '</span></div>';
}
?>
</div>
                       <div class="box1">
                    <div><strong>Name:</strong><span class="appointmentInfo"><?=$item['name']?></span></div>
                    <div  id="date"><strong>Date:</strong><span class="appointmentInfo"><?=date('Y-m-d', strtotime($item['created_at']))?></span></div>
                    </div>
                   
    <div><strong>Phone:</strong><span class="appointmentInfo"><?=$item['phone']?></span></div>




                    <div><strong>Email:</strong><span class="appointmentInfo"><?=$item['email']?></span></div>
                    <div><strong>Problem:</strong><span class="appointmentInfo"><?=$item['problem']?></span></div>
                    <div><strong>Address:</strong><span class="appointmentInfo"><?=$item['address']?></span></div>
                    <div><strong>Location:</strong><span class="appointmentInfo"><?=$item['location']?></span></div>
                    <div><strong> Booking through:</strong><span class="appointmentInfo"><?=$item['booking_type']?></span></div>
                   
                </div>
                <?php
            }
        } else {
            ?>
            <div class="noAppointment">No appointments yet.</div>
            <?php
        }
        ?>
    </section>
   
    
</body>
</html>
