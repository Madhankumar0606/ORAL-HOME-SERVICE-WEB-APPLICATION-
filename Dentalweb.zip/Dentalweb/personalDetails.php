<?php
include('header.html');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Details</title>
    <link rel="stylesheet" href="personalDetails.css">
    <style>
    
    </style>
</head>

<body>
    <div class="box">
        <div class="address">
            <div class="addressdetails">
                <form action="process_booking.php" method="post">
                    <div class="inputContainer">
                        <input type="text" name="no" id="no" placeholder="Floor no/ House no">
                    </div>
                    <div class="inputContainer">
                        <textarea name="address" id="address" cols="30" rows="5" placeholder="Address"></textarea>
                    </div>
            </div>
        </div>

        <div class="address">
            <div class="contactdetails">
                <div class="inputContainer">
                    <input type="email" name="email" id="email" placeholder="Email Id">
                </div>
                <div class="inputContainer">
                    <input type="text" name="phone" id="phone" placeholder="Phone">
                </div>
            </div>
        </div>
        <div class="buttonBox">
        <button type="submit" name="confirmDetails">Confirm Details</button>
</div>
        </form>
    </div>
</body>

</html>
