<?php
include('header.html');
include('connection.php');

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "SELECT * FROM prescription WHERE id = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($result)) {
        $name = $row['name'];
        $age = $row['age'];
        $gender = $row['gender'];
        $number = $row['phone'];
        $detail = $row['detail'];

        // Fetch image paths
        $scan_image = $row['scan_image'];
        $prescription_image = $row['prescription_image'];
    } else {
        echo "User not found";
        exit;
    }
} else {
    echo "User ID not in URL";
    exit;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./booking_type.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Patient Details</title>
    <style>
        .headerform{
            background:#126983;
            margin-bottom:20px;
            display:flex;
            justify-content:space-between;
        }
        .headerform div{
            color:white;
            padding:5px;
            font-size:15px;
            margin:5px 0px;
            line-height:25px;
            
        }
        .location{
            display:flex;
            justify-content:space-between;
        }
    .button {
        text-align: center;
    }

    .submitbtn {
        display: inline-block;
        padding: 10px 10px;
         width:80%;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
    }
    img{
        width:100px;
        height:100px;
    }
    </style>
</head>
<body>

    <div class="body">
        <form action="" method="post">
        <div class="headerform">
                <img src="LOGO1.png" alt="">
                <div class="location">
                    <div>162, Poonamallee High Rd, Velappanchavadi,
                        <BR> Chennai, Tamil Nadu 600077</div>
                    <div>+91 893999424,<br>+044 26801583</div>
</div></div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="name" id="name" value="<?= $name ?>">
                </div>
            </div>
            <div class="container">
               
</div>
                <div class="container">
                <div class="labelcontainer">
                    <label for="email">Age</label>
                </div>
                <div class="inputcontainer">
                    <input type="number" name="age" id="age"  value="<?= $age ?>">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="gender">Gender</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="gender" id="gender" value="<?= $gender ?>">
                  
                </div>
               </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="number">Mobile Number</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="number" id="number"  value="<?= $number ?>">
                </div>
            </div>
        

            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Detail Description About the Patient Symptom</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="problem" id="problem" cols="30" rows="5" ><?= $detail?></textarea>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">X-Ray/ Scan Photo:</label>
                </div>
                <div class="inputcontainer">
                <img src="./Doctor/report/<?= $scan_image ?>" alt="Prescription Photo">
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Prescription Photo</label>
                </div>
                <div class="inputcontainer">
    <img src="./Doctor/report/<?= $prescription_image ?>" alt="Prescription Photo">
</div>

            </div>
            <div class="button">
    <a href="generate_pdf.php?id=<?= $id ?>" class="submitbtn">Download</a>
</div>

        </form>
    </div>
</body>
</html>