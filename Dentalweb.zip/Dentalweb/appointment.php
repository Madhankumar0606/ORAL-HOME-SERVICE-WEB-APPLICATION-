<?php

session_start();
include('connection.php');
include('header.html');

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location: login_register.php');
    exit(); // Stop further execution of the script
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="appointment.css">
    <title>Book Appointment </title>
    <style>
        .btn{
    width:100%;
}
    </style>
</head>
<body>
    <h3>Welcome to Our Dental Clinic, <span><?php echo $_SESSION['auth_user']['name']; ?></span></h3>
  <div class="centerbox">
    <div class="appointtype">
        <div class="book">
            <a href="bookingtype.php">
        <button type="submit" class="btn" name="bookappoint">Book Your Appointment</button>
</a>
</div>
<div class="book">
    <a href="labTest.php">
        <button type="submit" class="btn" name="bookappoint">Add Test</button>
        </a>
        </div>
<div class="book">
    <a href="view_appointment.php">
        <button type="submit" class="btn" name="bookappoint">View Your Appointment</button>
        </a>
        </div>
        <div class="book">
    <a href="viewPrescription.php">
        <button type="submit" class="btn" name="bookappoint">View Your Prescription</button>
        </a>
        </div>
</div>
</div>
<?php 
include('footer.php');
?>
</body>
</html>
