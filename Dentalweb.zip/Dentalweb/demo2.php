<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }

        #sidebar {
            height: 100%;
            width: 0;
            position: fixed;
            background-color: #333;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px; /* Adjusted to match header height */
            color: white;
            text-align: center;
        }

        #content {
            margin-left: 0;
            padding: 20px;
            transition: margin-left 0.5s;
        }

        #content h2 {
            color: #333;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        ul li {
            padding: 10px;
            border-bottom: 1px solid #555;
        }

        a {
            text-decoration: none;
            color: white;
        }

        a:hover {
            color: #ddd;
        }

        #sidebarCollapse {
            position: fixed;
            left: 10px;
            top: 10px;
            cursor: pointer;
            background-color: #333; /* Background color matching the header */
            padding: 10px;
            border: none;
            color: white;
            font-size: 20px;
        }

        #sidebarCollapse i {
            font-size: 20px;
            color: white;
        }
    </style>
</head>

<body>
    <div class="header">Admin Panel</div>

    <div id="sidebar">
        <ul>
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Users</a></li>
            <li><a href="#">Orders</a></li>
            <li><a href="#">Settings</a></li>
        </ul>
    </div>

    <div id="content">
        <button id="sidebarCollapse" onclick="toggleSidebar()">☰</button>
        <h2>Dashboard</h2>
        <p>Welcome to the admin panel. Select an option from the sidebar.</p>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const content = document.getElementById('content');

            if (sidebar.style.width === '250px') {
                sidebar.style.width = '0';
                content.style.marginLeft = '0';
            } else {
                sidebar.style.width = '250px';
                content.style.marginLeft = '250px';
            }
        }
    </script>
</body>

</html>
