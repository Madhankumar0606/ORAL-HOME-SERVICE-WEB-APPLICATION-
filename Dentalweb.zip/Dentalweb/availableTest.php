<?php
include('function.php');
include('header.html');

$testType = getAllActive("testtype");

if (isset($_GET['testtype'])) {
    $testtype_slug = urldecode($_GET['testtype']);

    $testType_data = getSlugActive("testtype", $testtype_slug);

    if ($testType_data) {
        $testType = mysqli_fetch_array($testType_data);
        $tid = $testType['id'];

        if ($testType) {
            $alltest = getTestByType("alltest", $tid);

            if (mysqli_num_rows($alltest) > 0) {
                echo '<div class="testlist">';
                echo '<h2 class="cate_type">' . $testType['name'] . '</h2>';
                echo '<ul class="productprofile">';
                foreach ($alltest as $product) {
                    echo '<li class="member">';
                    echo '<div class="card">';

                    echo '<div class="cardbody">';
                    echo '<div class="name1">';
                    echo '<a href="product-view.php?product=' . $product['id'] . '">' . $product['name'] . '</a>';
                    echo '</div>';
                    echo '<div class="flexbutton">';
                    echo '<div class="price">';
                    echo '<s>' . $product['original_price'] . '</s>';
                    echo '<span class="selling">' . $product['selling_price'] . '</span>';
                    echo '</div>';
                    echo  '<div class="cartbutton">';
                    echo '<form action="add_to_cart.php?test_id=' . $product['id'] . '" method="post">';
                    echo '<button type="submit" name="addCart" class="cart">Add</button>';
                    echo '</form>';
                    echo '</div>';
                    echo '</div>';
                    echo  '</div>';
                    echo '</div>';
                    echo '</li>';
                }
                echo '</ul>';
                echo '</div>';
            } else {
                echo '<div class="noresult">';
                echo "No results found.";
                echo '</div>';
            }

            // Display success message if added to cart
            if (isset($_GET['added_to_cart']) && $_GET['added_to_cart'] == 'true') {
                echo '<div class="success-message">Item added to cart successfully!</div>';
            }
        } else {
            echo "Type not found";
        }
    } else {
        // Print the SQL error for debugging
        echo "SQL Error: " . mysqli_error($con);
    }
} else {
    echo "Type parameter not provided";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="availableTest.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Test</title>

    <style>
       /* Add this CSS to your stylesheet */
       .success-message {
           color: green;
           margin-top: 10px;
       }
    </style>
</head>
<body>

</body>
</html>
