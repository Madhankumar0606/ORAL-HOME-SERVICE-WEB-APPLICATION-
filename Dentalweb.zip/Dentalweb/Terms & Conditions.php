
<?php
include('header.html');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms & Conditions</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            
        }
        .box{
            margin:10px;
            padding:10px;
        }

        h2 {
            color: #333;
        }

        h3 {
            color: #444;
        }

        h4 {
            color: #555;
        }

        div {
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="box">
    <h2>Terms and Conditions for Online Booking</h2>
    <p>Welcome to ORAL Home. Before proceeding with your online booking, please carefully read and understand the following terms and conditions:</p>

    <h3>1. Appointment Booking:</h3>
    <h4>1.1. Appointment Confirmation:</h4>
    <div>
        By using our online booking system, you acknowledge that the appointment is subject to availability and confirmation.
        The appointment is considered confirmed only after you receive a confirmation email or notification from us.
    </div>

    <h4>1.2. Cancellation and Rescheduling:</h4>
    <div>
        If you need to cancel or reschedule your appointment, we kindly request that you provide at least 24 hours' notice.
        Late cancellations may be subject to a cancellation fee.
    </div>

    <h4>1.3. Emergency Situations:</h4>
    <div>
        In case of a dental emergency, please contact our clinic directly rather than relying solely on the online booking system.
    </div>

    <h3>2. Patient Information:</h3>
    <h4>2.1. Accurate Information:</h4>
    <div>
        You are responsible for providing accurate and up-to-date information during the booking process.
        Ensure that your contact details are correct for appointment notifications.
    </div>

    <h4>2.2. Medical History:</h4>
    <div>
        It is essential to inform us of any changes in your medical history, allergies, or medications.
        This information helps us provide you with the best possible dental care.
    </div>

    <h3>3. Privacy and Data Security:</h3>
    <h4>3.1. Data Confidentiality:</h4>
    <div>
        We prioritize the privacy and security of your personal information.
        Your data will be used solely for the purpose of managing your appointments and providing dental care.
    </div>

    <h4>3.2. Third-Party Services:</h4>
    <div>
        Our online booking system may use third-party services. Please review their terms and conditions for additional information.
    </div>

    <h3>4. Clinic Policies:</h3>
    <h4>4.1. Payment:</h4>
    <div>
        Payment is due at the time of the appointment unless other arrangements are made in advance.
    </div>

    <h4>4.2. Insurance:</h4>
    <div>
        If you have dental insurance, please provide the necessary details during the booking process.
    </div>

    <h4>4.3. Children and Minors:</h4>
    <div>
        For appointments involving children or minors, a parent or legal guardian must be present or provide written consent.
    </div>

    <h3>5. Changes to Terms and Conditions:</h3>
    <h4>5.1. Updates:</h4>
    <div>
        We reserve the right to update these terms and conditions at any time.
        It is your responsibility to review them periodically for any changes.
        By proceeding with the online booking, you agree to abide by these terms and conditions.
        If you have any questions or concerns, please contact us directly.
    </div>

    <p>Thank you.</p>
    </div>
</body>

</html>
