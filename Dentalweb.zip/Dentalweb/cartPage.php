<?php
include('function.php'); 
include('connection.php'); 
include('header.html');

if (!isset($_SESSION['auth_user']['user_id'])) {
    header('location:login_register.php');
    exit();
}

if (isset($_POST['remove_product'])) {
    $test_id = $_POST['remove_product'];

    $remove_query = "DELETE FROM Carts WHERE test_id = ?";
    $stmt = mysqli_prepare($con, $remove_query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'i', $test_id);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo '<script>alert("Remove test successfully");</script>';
        } else {
            echo "Error removing the product (Test ID: $test_id)";
        }

        mysqli_stmt_close($stmt);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cartpage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Cart</title>
    <style>
     
    </style>
</head>
<body>
    <div class="count">
        <?php
        $itemCount = count(getCartItems());
        echo " cart Item : $itemCount";
        ?>
    </div> 
    <div class="body">
        <div class="patientDetails">
            <button class="adddetails" type="submit" name="details"><i class="fa fa-user"></i>Add Patient Details</button>
        </div>
        <div class="container">
            <?php
            $items = getCartItems();
            $overallTotal = 0; // Initialize overall total

            foreach ($items as $citem) {
                $total_price = $citem['selling_price'];
                $overallTotal += $total_price;
                $overallTotal += 99;
            ?>
            <div class="cart-item">
                <div class="item-details">
                    <div class="details">
                        <h5><?= $citem['name'] ?></h5>
                        <!-- Add more details as needed -->
                    </div>
                </div>
                <div class="price">
                    <div class="selling"></div>
                    <h5 class="item-total" data-selling-price="<?= $citem['selling_price'] ?>">
                        <?= ($total_price == 0) ? $citem['selling_price'] : $total_price ?>
                    </h5>
                </div>
                <div class="button">
                    <div class="remove-button">
                        <form action="" method="post">
                            <input type="hidden" name="remove_product" value="<?= $citem['test_id'] ?>">
                            <button class="remove deleteItem" type="submit">
                                <i class="fa fa-trash" style="margin-right: 10px;"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php
            }
            ?>
            <div class="addbtn">
                <a href="labTest.php">
                    <button type="submit" name="add" class="addTest">+ Add more Tests or Health Checks</button>
                </a>
            </div>
        </div>
      <!--  <div class="addapatientDetails">
            <i class="fa fa-user"></i>Add Another Patient
        </div>-->
        <div class="addapatientDetails">
            <input type="checkbox" name="doctorfee" id="doctorfee">
            <span class="online"> Get online Doctor Consultation for your Lab Reports</span>
            <Span class="nine">₹99/-</span>
        </div>
        <div class="ShowPrice">
            <div class="total">
                <h5>Total Price: $<?= $overallTotal ?></h5>
            </div>
            <div class="checkbtn">
                <form action="order2.php" method="post">
                    <button type="submit" name="checkout" class="checkout">Add Patient Details</button>
                </form>
            </div>
        </div>
    </div>
    <?php
    include('footer.php');
    ?>
    <script>
        // Add your JavaScript code here
    </script>
</body>
</html>
