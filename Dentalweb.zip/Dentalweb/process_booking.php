<?php

include('connection.php');
include('function.php');

if (isset($_POST['booking_type'])) {
    $bookingType = mysqli_real_escape_string($con, $_POST['booking_type']);
    $userId = $_SESSION['auth_user']['user_id'];

    $update_query = "UPDATE register SET booking_type = '$bookingType' WHERE id = '$userId'";
    $update_query_run = mysqli_query($con, $update_query);

    if ($update_query_run) {
        // Redirect based on the selected booking type
        switch ($bookingType) {
            case 'SMS':
                header('Location: SMS_booking.php');
                break;
            case 'Normal Call':
                header('Location: call_booking.php');
                break;
            case 'Video Call':
                header('Location: video_booking.php');
                break;
            default:
                // Redirect to a default page or handle the case as needed
                header('Location: default_page.php');
                break;
        }
        
    } else {
        echo "Error updating booking type: " . mysqli_error($con);
    }
}





else if (isset($_POST['submitAppointment'])) {
    // Assuming you have a database connection ($con) established
    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $phone = $_POST['number'];
    $address = $_POST['address'];
    $location = $_POST['location'];
    $appointmentDate = $_POST['appointmentDate'];
    $appointmentTime = $_POST['appointmentTime'];
    $problem = $_POST['problem'];
           
   
    $imageFileName =  $_POST['image'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = 'uploads/';
        $imageFileName = $targetDir . basename($_FILES['image']['name']);

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $imageFileName)) {
            // File upload successful
        } else {
            // File upload failed
            echo "Error: Unable to upload image.";
            exit;
        }
    }

    // Assuming you have a session started
    $userId = isset($_SESSION['auth_user']['user_id']) ? $_SESSION['auth_user']['user_id'] : '';

    if (!empty($userId)) {
        // Corrected SQL query to fetch booking_type
        $booking_type_query = "SELECT id, booking_type FROM register WHERE id='$userId'";
        $booking_type_result = mysqli_query($con, $booking_type_query);

        if ($booking_type_result) {
            $booking_type_row = mysqli_fetch_assoc($booking_type_result);
            $booking_type = $booking_type_row['booking_type'];

            $insert_sms_query = "INSERT INTO appointment (user_id, name, email, phone, address, age, gender, location, problem, booking_type, image) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = mysqli_prepare($con, $insert_sms_query);

            mysqli_stmt_bind_param($stmt, 'sssssssssss', $userId, $name, $email, $phone, $address, $age, $gender, $location, $problem, $booking_type, $imageFileName);

            $insert_sms_query_run = mysqli_stmt_execute($stmt);

            if ($insert_sms_query_run) {
                // Insert successful
                $_SESSION['booking_type'] = $booking_type; // Store booking type in session
                header('Location: appointmentSuccess.php');
                exit;
            } else {
                // Insert failed
                echo "Error: " . mysqli_error($con);
            }

            mysqli_stmt_close($stmt);
        } else {
            // Error in fetching booking_type
            echo "Error: " . mysqli_error($con);
        }
    } else {
        // User ID not set
        echo "User ID not set!";
    }

}


   //update profile
// Handle the form submission for updating the profile
else if (isset($_POST['updateprofile'])) {
    // Check if the fields exist in the POST data before using them
    $user_id = $_SESSION['auth_user']['user_id'];
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    // Use double quotes to specify column names and their new values in the SQL query
    $update_query = "UPDATE register SET name ='$name', email='$email', phone='$phone', age='$age',
        gender='$gender', password='$password' WHERE id = $user_id";

    $update_query_run = mysqli_query($con, $update_query);

    if ($update_query_run) {
        echo '<script>alert("Update successful");</script>';
        echo '<script>window.location.href = "userProfile.php";</script>';
    } else {
        echo "Update failed: " . mysqli_error($con); // Display the error message for debugging
    }
}

else if (isset($_POST['confirmDetails'])) {
    
 
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $no = mysqli_real_escape_string($con, $_POST['no']);

    // Assuming you have a session started
    $userId = isset($_SESSION['auth_user']['user_id']) ? $_SESSION['auth_user']['user_id'] : '';

    // Corrected SQL query to fetch booking_type
    $insert_query = "INSERT INTO orders (email, phone, address, flat_no, user_id) VALUES ('$email', '$phone', '$address', '$no', '$userId')";
    $result = mysqli_query($con, $insert_query);

    if ($result) {
       # echo "Data inserted successfully!";
       echo '<script>window.location.href = "allDetails.php";</script>';
    } else {
        echo "Error: " . mysqli_error($con);
    }

    mysqli_close($con);
}




?>






