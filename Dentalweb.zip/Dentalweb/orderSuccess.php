<?php
session_start(); // Start the session
include('header.html');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="appointmentSuccess.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Order  Success</title>
    <style>
        /* Add your custom styles for appointment success messages here */
       
    </style>
</head>
<body>
    <?php
    include('connection.php'); // Include your database connection file


    
        echo '<div class="container">';
        echo '<div class="success-container">';
        echo '<div class="iconbox">';
        echo '<div class="icon"><i class="fa fa-check-circle"></i></div>';
        echo '</div>';

        echo '<div class="successMsg">';
        echo '<h3>Thank You for Filling The Form</h3>';

     
            echo '<h6>YOUR ORDER HAS BEEN BOOKED.</h6>';
      
     
     

        echo '</div>';
        echo '<div class="button"><a href="appointment.php"><button type="sumbit" name="backbtn">Back To Appointment</a></button>';
        echo '<div>';
        echo '</div>';
      echo '</div>';
        unset($_SESSION['booking_type']); // Clear the session variable
    
    ?>
</body>
</html>
