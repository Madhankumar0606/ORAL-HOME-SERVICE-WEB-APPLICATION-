<?php
include('header.html');
include('connection.php');
include('function.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Details</title>
    <link rel="stylesheet" href="personalDetails.css">
    <style>
        :root {
            --button: #126983;
            --title: rgb(0, 99, 160);
        }

        * {
            margin: 0%;
            padding: 0%;
        }

        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        .box2 {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
        }

        .orderDetails,
        .priceDetails {
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25);
            padding: 10px;
            margin: 10px;
        }

        .details {
            padding: 10px;
        }

        .total {
            padding: 10px;
            display: flex;
            justify-content: space-between;
        }

        h4 {
            padding: 5px;
        }

        .PayButton {
            text-align: center;
            margin-top: 20px;
        }

        .pay-button {
            background-color: var(--button);
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .pay-button:hover {
            background-color: var(--title);
        }

        .payment {
            display: flex;
        }

        #onlinePaymentDetails {
            display: flex;
            justify-content: space-between;
        }

        #onlinePaymentDetails img {
            height: 80px;
            width: 80px;
            margin: 5px 20px;
        }

        .title {
            margin: 10px;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function () {
            $('body').on('click', '.buynow', function (e) {
                var totalAmount = $(this).data("price");
                var options = {
                    "key": "rzp_test_6ViRjFcmNyoV66",
                    "amount": totalAmount * 100, // Corrected the calculation
                    "name": "OralHome",
                    "description": "Payment",
                    "handler": function (response) {
                        // Your existing AJAX request here
                    },
                    "theme": {
                        "color": "#528FF0"
                    }
                };
                var rzp1 = new Razorpay(options);
                rzp1.open();
                e.preventDefault();
            });
        });
    </script>
</head>

<body>
    <div class="box">
        <div class="address">
            <h4 class="title">Personal Details</h4>
            <div class="addressdetails">
                <form action="orders.php" method="post">
                    <div class="inputContainer">
                        <input type="text" name="no" id="no" placeholder="Floor no/ House no">
                    </div>
                    <div class="inputContainer">
                        <textarea name="address" id="address" cols="30" rows="5" placeholder="Address"></textarea>
                    </div>
            </div>
        </div>

        <div class="address">
            <div class="contactdetails">
                <div class="inputContainer">
                    <input type="email" name="email" id="email" placeholder="Email Id">
                </div>
                <div class="inputContainer">
                    <input type="text" id="phone" name="phone" pattern="\d{10}" title="Please enter a 10-digit phone number" placeholder="Mobile Number" required>
                </div>
            </div>
        </div>

    </div>

    <div class="box2">
        <div class="container">
            <h4>Orders Details</h4>
            <div class="orderDetails">
                <?php
                $items = getCartItems();
                $overallTotal = 0; // Initialize overall total

                foreach ($items as $citem) {
                    $total_price = $citem['selling_price'];
                    $overallTotal += $total_price + 99;
                ?>
                    <div class="item-details">
                        <div class="details">
                            <h5><?= $citem['name'] ?></h5>
                            <!-- Add more details as needed -->
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
            <h4>Price</h4>
            <div class="priceDetails">
                <?php
                $items = getCartItems();
                $overallTotal = 0; // Initialize overall total

                foreach ($items as $citem) {
                    $total_price = $citem['selling_price'];
                    $overallTotal += $total_price;
                ?>
                <?php
                }
                ?>
                <div class="total">
                    <h5>MRP total</h5>
                    <h2> ₹<?= $overallTotal ?></h2>
                </div>
                <div class="total">
                    <h5>Doctor Consultation </h5>
                    <h2>₹99</h2>
                </div>
                <?php
                $overallTotal += 99;
                ?>
                <div class="total">
                    <h5>Payable Amount</h5>
                    <h2 style="color:red">₹<?= $overallTotal ?></h2>
                </div>
            </div>
        </div>
        <h4>Payment Mode</h4>
        <div class="paymentDetails">
            <div class="payment">
                <input type="hidden" name="payment" id="payment" value="">

                <label for="online">Online Payment</label>
                <input type="radio" name="payment" id="online" value="online" onclick="showOnlinePaymentDetails()">

            </div>
            <div id="onlinePaymentDetails" name="payment" value="online" style="display: none;">
                <!-- Online payment details here -->
     
            </div>
            <div class="payment">
                <label for="offline">Payment on Delivery</label>
                <input type="radio" name="payment" id="offline" value="offline" onclick="hideOnlinePaymentDetails()">
            </div>
        </div>
        <button data-price="<?= $overallTotal; ?>" class="btn btn-block btn-primary font-weight-bold py-3 buynow">Pay</button>
        </form>
    </div>

    <script>
        function showOnlinePaymentDetails() {
            document.getElementById('onlinePaymentDetails').style.display = 'block';
        }

        function hideOnlinePaymentDetails() {
            document.getElementById('onlinePaymentDetails').style.display = 'none';
        }
    </script>
</body>

</html>
