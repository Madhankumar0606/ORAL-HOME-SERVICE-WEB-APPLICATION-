<?php
include('header.html');
include('connection.php');  // Make sure to include your database connection file

if(isset($_POST['submitform'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Use prepared statement to prevent SQL injection
    $insert_query = "INSERT INTO contact (`name`, `email`, `message`) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($con, $insert_query);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, 'sss', $name, $email, $message);

    // Execute the statement
    $insert_query_run = mysqli_stmt_execute($stmt);

    // Check if the insertion was successful
    if ($insert_query_run) {
        echo '<script>alert("Form submitted successfully!");</script>';
        echo '<script>window.location.href = "home.php";</script>';
    } else {
        echo "Error: " . mysqli_error($con);
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}
?>
