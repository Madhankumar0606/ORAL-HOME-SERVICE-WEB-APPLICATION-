<?php
session_start();

include('connection.php');

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);
    $specialist = mysqli_real_escape_string($con, $_POST['specialist']);

    $duplicate = mysqli_query($con, "SELECT * FROM register WHERE email='$email'");

    if (mysqli_num_rows($duplicate) > 0) {
        echo "<script>alert('Email is already taken');</script>";
        header('location:addDoctor.php');
    } else {
        if ($password == $cpassword) {
            $insert_query = "INSERT INTO doctor_register (name, email, phone,age,gender, password, cpassword,specialist) VALUES ('$name', '$email', '$phone','$age','$gender', '$password', '$cpassword','$specialist')";
            $insert_query_run = mysqli_query($con, $insert_query);

            if ($insert_query_run) {
                $_SESSION['message2'] = "Doctor add Successfully";
                header('location:allDoctor.php');
            } else {
                $_SESSION['message2'] = "Something went Wrong";
                header('location:addDoctor.php');
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Add Doctor Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   <link rel="stylesheet" href="./login_register.css">
   <link rel="stylesheet" href="adminSideBar.css">
    <style>
        /* Add your styles here if needed */
        #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="LOGO1.Png">
        </div>
    <div class="mainbody">
  




    <div class="container">
        <h2>Add Doctor</h2>
       
   
        <form action="" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Mobile Number</label>
                <input type="text" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="phone">Age</label>
                <input type="text" id="age" name="age" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <input type="text" id="gender" name="gender" required>
            </div>
            <div class="form-group">
                <label for="specialist">Specialist</label>
                <input type="text" id="specialist" name="specialist" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
           title="Password must contain at least 8 characters, including at least one digit, one lowercase letter, and one uppercase letter." required>
            </div>
            <div class="form-group">
                <label for="cpassword"> Confirm Password</label>
                <input type="password" id="cpassword" name="cpassword"  pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
           title="Password must contain at least 8 characters, including at least one digit, one lowercase letter, and one uppercase letter."required>
            </div>
            <div class="form-group">
               
                <input type="submit" name="register"value="Add">
            </div>
        </form>
    </div>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  <script src="admin.js"></script>
</body>

</html>
