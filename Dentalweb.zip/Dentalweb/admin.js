
/*function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');

    if (sidebar.style.width === '250px') {
        sidebar.style.width = '0';
        content.style.marginLeft = '0';
    } else {
        sidebar.style.width = '250px';
        content.style.marginLeft = '250px';
    }
}

function toggleSublist(sublistId) {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const sublist = document.getElementById(sublistId);

    // Toggle the sublist visibility
    sublist.style.display = sublist.style.display === 'none' ? 'block' : 'none';

    // Prevent closing the sidebar when clicking on the sublist
    event.stopPropagation();
}*/


function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');

    if (sidebar.style.width === '250px') {
        sidebar.style.width = '0';
        content.style.marginLeft = '0';
    } else {
        sidebar.style.width = '250px';
        content.style.marginLeft = '250px';
    }
}

function toggleSublist(sublistId) {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const sublist = document.getElementById(sublistId);

    // Toggle the sublist visibility
    sublist.style.display = sublist.style.display === 'none' ? 'block' : 'none';

    // Prevent closing the sidebar when clicking on the sublist
    event.stopPropagation();
}