<?php
include('function.php');
include('connection.php');

// Add this function to your function.php file
function getSelectTestId($table, $test_id) {
    global $con;

    $query = "SELECT * FROM $table WHERE id = $test_id";

    // Debugging: Output the SQL query
    echo "SQL Query: $query<br>";

    $result = mysqli_query($con, $query);

    return $result;
}

if (isset($_GET['test_id'])) {
    $test_id = $_GET['test_id'];

    // Sanitize the test_id
    $test_id = mysqli_real_escape_string($con, $test_id);

    // Check if the user is authenticated
    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
        // User is authenticated, retrieve the user's ID from the session
        $user_id = $_SESSION['auth_user']['user_id'];

        // Check if the product is already in the cart for the user
        $cart_query = "SELECT * FROM carts WHERE user_id = ? AND test_id = ?";
        $stmt = mysqli_prepare($con, $cart_query);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ii", $user_id, $test_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) > 0) {
                // Product is already in the cart, display an alert
                echo '<script>alert("Product is already in the cart.");</script>';
                echo '<script>window.location.href = "cartpage.php";</script>';
            } else {
                // Fetch product data based on $test_id using your function
                $test_data = getSelectTestId("alltest", $test_id);

                // Debugging: Output fetched test data
                //var_dump($test_data);

                $test = mysqli_fetch_array($test_data);

                // Debugging: Output fetched test data
                //var_dump($test);

                if ($test) {
                    // Insert the test into the cart table, including the user's ID
                    $sql = "INSERT INTO carts (user_id, test_id, total_price) VALUES (?, ?, ?)";
                    $stmt = mysqli_prepare($con, $sql);

                    if ($stmt) {
                        // Use selling_price as total_price
                        $total_price = $test['selling_price'];

                        mysqli_stmt_bind_param($stmt, "iid", $user_id, $test_id, $total_price);

                        if (mysqli_stmt_execute($stmt)) {
                            // Cart item added successfully
                            echo '<script>alert("Cart item added successfully");</script>';
                            echo '<script>window.location.href = "cartPage.php";</script>';
                        } else {
                            // Error adding to cart
                            echo 'Error executing SQL statement: ' . mysqli_error($con);
                        }

                        mysqli_stmt_close($stmt);
                    } else {
                        echo 'Error preparing SQL statement: ' . mysqli_error($con);
                    }
                } else {
                    echo "Test Not Found";
                }
            }
        } else {
            echo 'Error preparing SQL statement: ' . mysqli_error($con);
        }
    } else {
        echo '<script>alert("Please log in to add items to the cart.");</script>';
        echo '<script>window.location.href = "login_register.php";</script>';
    }
} else {
    // Handle the case when 'test_id' is not set
    echo "Test ID not provided in the form.";
}
?>
