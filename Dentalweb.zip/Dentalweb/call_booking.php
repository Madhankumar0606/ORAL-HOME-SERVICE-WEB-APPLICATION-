<?php

include('header.html');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="booking_type.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Normal Call</title>
    <style>
     
    </style>
</head>
<body>
<div class="title">
<h3><i class="fa fa-phone"></i>Normal Call</h3>
    </div>
    <div class="body">
        <form action="process_booking.php" method="post">
            <div class="container">
                <div class="labelcontainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="name" id="name" required>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="email">Email</label>
                </div>
                <div class="inputcontainer">
                    <input type="email" name="email" id="email" required>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="email">Age</label>
                </div>
                <div class="inputcontainer">
                    <input type="number" name="age" id="age" required>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="email">Gender</label>
                </div>
                <div class="inputcontainer">
                    <div class="gender">
        <select name="gender" id="gender">
        <option value="option">Select </option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        </select>
</div>
    </div>
</div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="number">Mobile Number</label>
                </div>
                <div class="inputcontainer">
                <input type="text" id="number" name="number" pattern="\d{10}" title="Please enter a 10-digit phone number" required>
                   
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="address">Address</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="address" id="address" cols="30" rows="5" required></textarea>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="location">Location</label>
                </div>
                <div class="inputcontainer">
                    <input type="text" name="location" id="location" required>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="appointmentDate">Appointment Date</label>
                </div>
                <div class="inputcontainer">
                    <input type="date" name="appointmentDate" id="appointmentDate" required>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="appointmentTime">Appointment Time</label>
                </div>
                <div class="inputcontainer">
                    <input type="time" name="appointmentTime" id="appointmentTime" required>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Dental Problem Description</label>
                </div>
                <div class="inputcontainer">
                    <textarea name="problem" id="problem" cols="30" rows="5" required></textarea>
                </div>
            </div>
            <div class="container">
                <div class="labelcontainer">
                    <label for="problem">Upload Teeth Image</label>
                </div>
                <div class="inputcontainer">
                    <input type="file" name="image" id="image">
                </div>
            </div>
            <div class="button">
                <button type="submit" class="submitbtn" name="submitAppointment">Submit</button>
            </div>
        </form>
    </div>
    <?php 
include('footer.php');
?>
</body>
</html>
