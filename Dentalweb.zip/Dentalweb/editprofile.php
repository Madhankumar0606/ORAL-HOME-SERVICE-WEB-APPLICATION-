<?php
include('function.php');
include('header.html');

if (!isset($_SESSION['auth_user']['user_id'])) {
    header('location: login_register.php'); // Redirect to the login page if the user is not logged in
    exit();
}

$user_id = $_SESSION['auth_user']['user_id'];

// Query the database to get the user's details
$user_query = "SELECT * FROM register WHERE id = $user_id";
$user_query_run = mysqli_query($con, $user_query);

if (!$user_query_run) {
    die("Database query error: " . mysqli_error($con));
}

if ($user_query_run && $user_data = mysqli_fetch_assoc($user_query_run)) {
    // User data is available, you can display and edit it
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="editProfile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Add your styles here */
    </style>
</head>

<body>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="editProfile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Add your styles here */
    </style>
</head>

<body>
    <div class="ProfileBox">
        <div class="editProfile">
          
        </div>
        <form action="process_booking.php" method="post">
        
            <div class="container">
            <h3 style="margin: 10px;">Edit Profile</h3>
                <div class="labelContainer">
                    <label for="name">Name</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="name" id="name" value="<?= htmlspecialchars($user_data['name']) ?>">
                </div>

                <!-- Add similar sections for other fields like email, age, gender, phone, and password -->
                <div class="labelContainer">
                    <label for="email">Email</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="email" id="email" value="<?= htmlspecialchars($user_data['email']) ?>">
                </div>

                <div class="labelContainer">
                    <label for="age">Age</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="age" id="age" value="<?= htmlspecialchars($user_data['age']) ?>">
                </div>

                <div class="labelContainer">
                    <label for="gender">Gender</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="gender" id="gender" value="<?= htmlspecialchars($user_data['gender']) ?>">
                </div>

                <div class="labelContainer">
                    <label for="phone">Phone Number</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($user_data['phone']) ?>">
                </div>

                <div class="labelContainer">
                    <label for="password">Password</label>
                </div>
                <div class="inputContainer">
                    <input type="text" name="password" id="password" value="<?= htmlspecialchars($user_data['password']) ?>"pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$"
           title="Password must contain at least 8 characters, including at least one digit, one lowercase letter, and one uppercase letter.">
                </div>

                <button type="submit" name="updateprofile" class="update">Update Profile</button>
            </div>
        </form>
    </div>
</body>

</html>




<?php
} 
?>
