
<?php
include('header.html');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Oral Home</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            
            color: #333;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
        }

        header {
            margin:20px 0px;
            background-color: #126983;
            color: #fff;
            text-align: center;
            padding: 40px 20px;
        }

        header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        header p {
            font-size: 1.2em;
        }

        .section {
            line-height: 1.6;
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        section h2 {
            color: #126983;
            font-size: 2em;
            margin-bottom: 20px;
        }

        section p {
            font-size: 1.1em;
            line-height: 1.8;
            margin-bottom: 20px;
        }

        footer {
            background-color: #126983;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        footer p {
            margin: 0;
        }
    </style>
</head>
<body>

    <header>
        <h1>Welcome to Oral Home</h1>
        <p>Your Trusted Destination for Comprehensive Dental Care</p>
    </header>

    <section id="about"class="section" >
        <h2>About Us</h2>
        <p>Oral Home is a leading dental clinic committed to providing high-quality, compassionate dental care to our community. With a team of skilled and experienced dental professionals, we aim to create a warm and welcoming environment for our patients.</p>

        <p>At Oral Home, we understand the importance of a healthy and beautiful smile. Our state-of-the-art facilities are equipped with the latest dental technology, allowing us to offer a wide range of services, from routine cleanings to advanced cosmetic and restorative procedures.</p>

        <p>Our team of dentists, hygienists, and support staff work together to ensure that every patient receives personalized and attentive care. We believe in building long-lasting relationships with our patients, fostering a sense of trust and confidence in our dental services.</p>
    </section>

    <section id="mission-vision"class="section">
        <h2>Our Mission</h2>
        <p>Our mission at Oral Home is to improve and maintain the oral health of our patients by delivering exceptional dental care. We strive to educate our patients on the importance of preventive dentistry and empower them to make informed decisions about their oral health.</p>

        <h2>Our Vision</h2>
        <p>We envision a community with healthy, beautiful smiles. Through continuous education, innovation, and a patient-centered approach, we aim to be a trusted partner in our patients' oral health journey.</p>
    </section>

    <section id="team" class="section">
        <h2>Meet Our Team</h2>
        <p>Our dedicated team of dental professionals is passionate about providing comprehensive and compassionate care. With a commitment to ongoing education and training, we stay abreast of the latest advancements in dentistry to offer the best possible treatment options to our patients.</p>

        <!-- You can include images and brief bios of key team members -->
    </section>

    <footer>
        <p>Contact Oral Home to schedule your appointment and experience exceptional dental care.</p>
        <p>Phone:+91 893999424,+044 26801583| websitesaveetha@gmail.com</p>
    </footer>

</body>
</html>
