<?php
include('header.html');
?>
<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Dental Care Services, Preventive services include:, Our Services, GeneralDentist &amp;amp; Prosthodontist, Our Mission, Our Values, High Quality Treatment, contact us">
    <meta name="description" content="">
    <title>Home</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Home1.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 5.21.10, nicepage.com">
    <meta name="referrer" content="origin">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:100,200,300,400,500,600,700,800,900">
    
<link rel="stylesheet" href="Home1.css">
    
    
    
    
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
  <meta data-intl-tel-input-cdn-path="intlTelInput/"></head>
  <body data-path-to-root="./" data-include-products="false" class="u-body u-xl-mode" data-lang="en"><header class="u-clearfix u-custom-color-1 u-header u-header" id="sec-dc45"><div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-custom-font u-text u-text-default u-text-1">ORAL HOME</h1>
        <nav class="u-menu u-menu-one-level u-offcanvas u-menu-1">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px;">
            <a class="u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
          <div class="u-custom-menu u-nav-container">
            <ul class="u-nav u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="Home.html" style="padding: 10px 20px;">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="About.html" style="padding: 10px 20px;">About</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="Contact.html" style="padding: 10px 20px;">Contact</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="products/products.html" style="padding: 10px 20px;">Services</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" target="_blank" style="padding: 10px 20px;">Book appointment</a>
</li></ul>
          </div>
          <div class="u-custom-menu u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Home.html">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="About.html">About</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Contact.html">Contact</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="products/products.html">Services</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" target="_blank">Book appointment</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
      </div></header>
    <section class="u-clearfix u-section-1" id="carousel_c5a4">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="data-layout-selected u-clearfix u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-col">
              <div class="u-size-30">
                <div class="u-layout-col">
                  <div class="u-container-style u-layout-cell u-left-cell u-right-cell u-size-60 u-layout-cell-1" data-animation-name="customAnimationIn" data-animation-duration="1500">
                    <div class="u-container-layout u-valign-middle u-container-layout-1">
                      <h4 class="u-text u-text-1">about us</h4>
                      <h1 class="u-text u-text-custom-color-1 u-text-2">HOME DENTAL SERVICES</h1>
                    </div>
                  </div>
                </div>
              </div>
              <div class="u-size-30">
                <div class="u-layout-row">
                  <div class="u-align-center u-container-style u-layout-cell u-left-cell u-size-60 u-layout-cell-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="250">
                    <div class="u-container-layout u-container-layout-2">
                      <p class="u-text u-text-3"> At Oral Home, we believe that dental care should be accessible, convenient, and comfortable for everyone. We are dedicated to delivering top-notch dental services in the comfort of your own home.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-1" src="images/oralhome1.jpg" alt="" data-image-width="461" data-image-height="461">
      </div>
    </section>
    <section class="u-clearfix u-custom-color-1 u-section-2" id="carousel_8d7f">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <div class="data-layout-selected u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-row">
              <div class="u-container-style u-layout-cell u-left-cell u-size-22-lg u-size-22-sm u-size-22-xs u-size-25-xl u-size-60-md u-layout-cell-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="250">
                <div class="u-container-layout u-container-layout-1">
                  <h2 class="u-text u-text-1">Preventive services include:</h2>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-size-15-xl u-size-18-lg u-size-18-sm u-size-18-xs u-size-60-md u-layout-cell-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                <div class="u-container-layout u-container-layout-2">
                  <ul class="u-text u-text-2">
                    <li style="">Dentures</li>
                    <li style="">Extractions</li>
                    <li style="">Gum treatment</li>
                    <li style="">Implants</li>
                    <li style="">Oral surgery</li>
                    <li style="">Laminates</li>
                    <li style="">Tooth whitening<br>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-right-cell u-size-20 u-size-60-md u-layout-cell-3" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                <div class="u-container-layout u-container-layout-3">
                  <p class="u-text u-text-3"> "In order to live, one needs pulvinar, pulvinar, to be specific. To live, power is really needed. However, it is not at all power, but very power, or whatever power we call it. Then, fringilla is the bedrock, with no one.</p>
                  <a href="https://nicepage.com/k/hacker-html-templates" class="u-active-palette-1-light-3 u-btn u-button-style u-hover-palette-1-light-3 u-text-active-black u-text-hover-black u-text-palette-1-base u-white u-btn-1">Book Appointment</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-grey-5 u-section-3" id="carousel_6363">
      <div class="u-container-style u-group u-image u-shape-rectangle u-image-1" data-animation-name="flipIn" data-animation-duration="1500" data-animation-direction="X" data-animation-delay="750" data-image-width="1378" data-image-height="1378">
        <div class="u-container-layout u-container-layout-1"></div>
      </div>
      <div class="u-align-center u-container-align-left u-container-style u-expanded-width-xs u-group u-white u-group-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
        <div class="u-container-layout u-container-layout-2">
          <h3 class="u-text u-text-1">About Our Dental Clinic&nbsp;<br>and why choose us?
          </h3>
          <p class="u-custom-font u-text u-text-2"> Our team is composed of highly skilled and experienced dentists and dental hygienists who are dedicated to providing top-notch care. We stay updated with the latest advancements in dental technology and techniques to ensure you receive the best treatment.</p>
          <div class="custom-expanded u-container-style u-custom-color-1 u-group u-group-3">
            <div class="u-container-layout u-container-layout-3">
              <div class="fr-view u-clearfix u-rich-text u-text u-text-3">
                <h1 style="text-align: center;">
                  <span style="font-size: 2.25rem; font-weight: 700;">Flexible Scheduling: <br>
                  </span>
                </h1>
                <p style="text-align: center;">We understand that your time is valuable. With our flexible scheduling options, you can choose appointment times that suit your schedule, including evenings and weekends.</p>
              </div>
            </div>
          </div>
          <a href="https://nicepage.me" class="u-active-black u-align-left u-btn u-button-style u-hover-black u-palette-1-base u-text-active-white u-text-body-alt-color u-text-hover-white u-btn-1">Contact us</a>
        </div>
      </div>
    </section>
    <section class="u-align-center u-clearfix u-section-4" id="carousel_c486">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-text u-text-default u-text-palette-1-base u-text-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="0">Our Services</h2>
        <p class="u-text u-text-grey-50 u-text-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="250">Consectetur adipiscing elit nullam nunc justo sagittis suscipit ultrices.</p>
        <div class="u-expanded-width u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-align-center u-container-align-center u-container-style u-grey-5 u-list-item u-repeater-item u-list-item-1" data-animation-direction="Up" data-animation-name="customAnimationIn" data-animation-duration="1500">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-1"><span class="u-align-center u-icon u-icon-circle u-palette-1-base u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 511.818 511.818" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-56f0"></use></svg><svg class="u-svg-content" viewBox="0 0 511.818 511.818" id="svg-56f0"><g><path d="m496.818 393.405h-10v-75.129c0-6.102-3.649-11.342-8.879-13.685 5.626-9.142 8.879-19.893 8.879-31.392 0-33.126-26.95-60.076-60.076-60.076h-34.924c-8.284 0-15 6.716-15 15 0 8.355-6.797 15.152-15.152 15.152h-40.715c-24.814 0-45 20.188-45 45.001 0 6.939 1.581 13.514 4.398 19.389-2.717 2.715-4.398 6.466-4.398 10.611v75.128h-13.807l-106.76-51.597c-4.047-1.957-8.562-2.991-13.058-2.991h-127.326c-8.284 0-15 6.716-15 15v60c0 8.284 6.716 15 15 15h113.588l106.766 51.599c4.047 1.956 8.561 2.989 13.053 2.989h248.412c8.284 0 15-6.716 15-15v-59.999c-.001-8.284-6.716-15-15.001-15zm-70.867 0v-60.129h30.867v60.129zm-30-60.129v60.128h-30v-60.128zm-75-60.001h40.715c19.641 0 36.394-12.607 42.591-30.152h22.485c16.584 0 30.076 13.492 30.076 30.076s-13.492 30.076-30.076 30.076c-.007 0-.013.001-.019.001h-105.752c-.007 0-.013-.001-.019-.001-8.272 0-15-6.729-15-15-.001-8.271 6.728-15 14.999-15zm-15 60.001h30v60.128h-30zm175.867 120.128-233.412-.001-106.766-51.6c-4.046-1.954-8.559-2.987-13.052-2.987h-98.588v-30l112.327.001 106.761 51.597c4.047 1.957 8.562 2.991 13.058 2.991h219.673v29.999z"></path><path d="m419.915 168.137h3.992v3.992c0 8.284 6.716 15 15 15s15-6.716 15-15v-3.992h3.993c8.284 0 15-6.716 15-15s-6.716-15-15-15h-3.993v-3.993c0-8.284-6.716-15-15-15s-15 6.716-15 15v3.993h-3.992c-8.284 0-15 6.716-15 15s6.716 15 15 15z"></path><path d="m344.096 77.407h3.992v3.992c0 8.284 6.716 15 15 15s15-6.716 15-15v-3.992h3.993c8.284 0 15-6.716 15-15s-6.716-15-15-15h-3.993v-3.993c0-8.284-6.716-15-15-15s-15 6.716-15 15v3.993h-3.992c-8.284 0-15 6.716-15 15s6.716 15 15 15z"></path><path d="m253.879 181.252h3.993v3.993c0 8.284 6.716 15 15 15s15-6.716 15-15v-3.993h3.992c8.284 0 15-6.716 15-15s-6.716-15-15-15h-3.992v-3.992c0-8.284-6.716-15-15-15s-15 6.716-15 15v3.992h-3.993c-8.284 0-15 6.716-15 15s6.716 15 15 15z"></path>
</g></svg></span>
                <h5 class="u-align-center u-text u-text-palette-1-base u-text-3">dental care</h5>
                <p class="u-align-center u-text u-text-grey-50 u-text-4"> It involves regular check-ups, cleanings, and addressing dental issues promptly to ensure overall well-being.</p>
              </div>
            </div>
            <div class="u-align-center u-container-align-center u-container-style u-grey-5 u-list-item u-repeater-item u-list-item-2" data-animation-direction="Up" data-animation-name="customAnimationIn" data-animation-duration="1500">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-2"><span class="u-align-center u-icon u-icon-circle u-palette-1-base u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-ea0e"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" id="svg-ea0e"><g><path d="m512 128.533-80.643-44.192-44.191-84.341-31.581 61.281c-14.219-4.49-29.016-6.77-44.15-6.77-27.924 0-57.382 9.293-82.364 25.76-24.982-16.466-54.441-25.76-82.364-25.76-80.895.001-146.707 65.813-146.707 146.708 0 48.802 23.407 77.079 56.083 115.237l51.954 161.935c6.283 20.105 24.647 33.609 45.717 33.609h9.033l63.271-119.556c.793-1.5 2.077-1.815 3.014-1.815s2.22.314 3.014 1.815l63.269 119.556h9.033c21.07 0 39.434-13.503 45.717-33.61l51.953-161.934c32.677-38.159 56.084-66.436 56.084-115.237 0-13.68-1.866-27.119-5.554-40.105zm-94.108 116.286c-10.203 20.215-27.934 39.65-42.552 56.713l-53.821 167.759-.04.126c-1.488 4.786-4.809 8.574-9.055 10.697l-53.822-101.703c-5.805-10.969-17.12-17.783-29.53-17.783s-23.726 6.814-29.53 17.783l-53.823 101.703c-4.247-2.123-7.566-5.91-9.055-10.696l-53.862-167.886c-25.245-29.466-52.802-59.179-52.802-100.313 0-64.353 52.354-116.707 116.707-116.707 31.37 0 58.167 14.506 82.364 33.056 31.691-24.293 67.848-39.354 108.311-30.169l-75.21 41.134 80.802 44.192 44.192 80.802 39.334-71.921c3.646 21.575 1.292 43.598-8.608 63.213zm-8.638-94.198-22.088 40.386-22.089-40.386-40.386-22.088 40.386-22.088 22.089-40.386 22.088 40.386 40.386 22.088z"></path><path d="m464.958 28.404h30v30h-30z"></path><path d="m279.457 198.895h30v30h-30z"></path>
</g></svg></span>
                <h5 class="u-align-center u-text u-text-palette-1-base u-text-5">Oral surgery</h5>
                <p class="u-align-center u-text u-text-grey-50 u-text-6"> Oral surgery is a specialized field of dentistry that involves surgical procedures to diagnose and treat a wide range of oral and maxillofacial conditions, including tooth extraction, dental implant placement, jaw surgery, and more, with a focus on improving oral health and function.</p>
              </div>
            </div>
            <div class="u-align-center u-container-align-center u-container-style u-grey-5 u-list-item u-repeater-item u-list-item-3" data-animation-name="customAnimationIn" data-animation-duration="1500">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-3"><span class="u-align-center u-icon u-icon-circle u-palette-1-base u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="-30 1 511 511.9996" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-2ba3"></use></svg><svg class="u-svg-content" viewBox="-30 1 511 511.9996" id="svg-2ba3"><path d="m260.855469 17.675781c-21.53125 12.726563-48.285157 12.722657-69.8125.003907-107.605469-63.640626-228.847657 56.125-179 174.695312 5.011719 11.957031 9.175781 24.234375 12.378906 36.5 1.726563 6.601562 7.691406 11.207031 14.515625 11.207031h111.511719v57.578125l-15.496094 2.613282c-8.167969 1.375-13.671875 9.109374-12.296875 17.277343 1.378906 8.195313 9.144531 13.671875 17.285156 12.296875l10.503906-1.769531v29.257813l-17.464843 2.910156c-8.171875 1.363281-13.691407 9.089844-12.328125 17.257812 1.355468 8.15625 9.066406 13.691406 17.261718 12.328125l12.53125-2.085937v29.574218l-17.464843 2.910157c-8.171875 1.359375-13.691407 9.085937-12.328125 17.257812 1.355468 8.152344 9.066406 13.6875 17.261718 12.328125l12.53125-2.089844v9.289063c0 30.320313 24.675782 54.984375 55 54.984375h40c30.328126 0 55-24.664062 55-54.984375v-34.28125l17.46875-2.910156c8.167969-1.359375 13.691407-9.085938 12.328126-17.257813-1.363282-8.167968-9.089844-13.683594-17.261719-12.328125l-12.535157 2.089844v-29.574219l17.46875-2.910156c8.167969-1.363281 13.691407-9.089844 12.328126-17.257812-1.363282-8.171876-9.089844-13.683594-17.261719-12.328126l-12.535157 2.085938v-29.539062l17.496094-2.949219c8.167969-1.375 13.671875-9.109375 12.296875-17.277344s-9.113281-13.675781-17.285156-12.296875l-12.503906 2.105469v-32.304688h111.15625c7.089843.460938 13.59375-4.15625 15.445312-11.097656 4.507813-16.894531 10.941407-32.671875 12.238281-35.261719 51.417969-119.027344-70.53125-239.859375-178.433593-176.046875zm9.59375 439.339844c0 13.78125-11.214844 24.992187-25 24.992187h-40c-13.785157 0-25-11.210937-25-24.992187v-14.285156l90-14.996094zm0-59.6875-90 14.992187v-29.574218l90-14.996094zm0-59.984375-90 14.996094v-29.316406l90-15.164063zm0-59.898438-90 15.164063v-52.523437h90zm141.296875-95.613281c-3.960938 9.171875-7.464844 18.636719-10.457032 28.257813h-351.003906c-3-9.871094-6.542968-19.691406-10.578125-29.320313-38.523437-91.632812 53.03125-186.382812 136.070313-137.269531 30.945312 18.28125 69.394531 18.28125 100.347656-.003906 83.585938-49.433594 175.246094 46.613281 135.621094 138.335937zm0 0"></path></svg></span>
                <h5 class="u-align-center u-text u-text-palette-1-base u-text-7">Implants</h5>
                <p class="u-align-center u-text u-text-grey-50 u-text-8"> A dental implant is a surgical component that serves as an artificial tooth root, providing a strong foundation for the placement of a replacement tooth or crown.</p>
              </div>
            </div>
            <div class="u-align-center u-container-align-center u-container-style u-grey-5 u-list-item u-repeater-item u-list-item-4" data-animation-direction="Up" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-4"><span class="u-align-center u-icon u-icon-circle u-palette-1-base u-icon-4"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-be11"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" id="svg-be11"><g><path d="m404.625 301.25h-74.88c-6.973-34.33-37.387-60.25-73.745-60.25s-66.772 25.919-73.745 60.25h-74.88c-4.483 0-8.731 2.005-11.58 5.466-2.85 3.461-4.001 8.015-3.141 12.414.233 1.192 9.952 48.824 9.952 48.824 11.109 51.491 18.449 85.507 29.101 107.503 12.239 25.273 30.085 36.543 57.863 36.543 11.398 0 27.858-1.317 39.159-12.703 14.583-14.694 14.409-37.724 14.122-75.878-.044-5.927-.091-12.056-.091-18.679 0-7.3 5.939-13.24 13.24-13.24s13.24 5.939 13.24 13.24c0 6.623-.046 12.752-.091 18.679-.288 38.155-.461 61.185 14.122 75.878 11.301 11.386 27.761 12.703 39.159 12.703 27.778 0 45.624-11.271 57.863-36.543 10.652-21.996 17.991-56.012 29.101-107.503 0 0 9.719-47.631 9.952-48.824.861-4.399-.291-8.953-3.141-12.414-2.849-3.461-7.097-5.466-11.58-5.466zm-24.556 60.377c-22.708 105.249-27.928 120.373-57.639 120.373-9.329 0-15.34-1.291-17.866-3.836-5.783-5.827-5.621-27.314-5.416-54.519.045-5.983.092-12.169.092-18.905 0-23.842-19.397-43.24-43.24-43.24s-43.24 19.397-43.24 43.24c0 6.736.046 12.922.092 18.905.205 27.205.367 48.692-5.416 54.519-2.526 2.546-8.537 3.836-17.866 3.836-29.71 0-34.931-15.124-57.639-120.374 0 0-4.564-21.73-6.293-30.376h260.725c-1.731 8.647-6.294 30.377-6.294 30.377zm-124.069-90.627c19.694 0 36.481 12.651 42.684 30.25h-85.368c6.203-17.599 22.99-30.25 42.684-30.25z"></path><path d="m403.954 31.929c-20.942-20.851-48.564-32.162-77.816-31.924-16.688.146-32.706 3.952-47.606 11.315-14.318 7.076-30.744 7.076-45.064 0-14.9-7.362-30.917-11.169-47.601-11.314-29.27-.266-56.879 11.074-77.82 31.924-21.448 21.355-33.183 49.789-33.041 80.064.164 34.268 6.562 63.823 19.56 90.356 2.519 5.142 7.745 8.401 13.471 8.401h295.929c5.726 0 10.952-3.259 13.471-8.401 12.998-26.533 19.396-56.088 19.56-90.356v-.001c.139-30.276-11.595-58.709-33.043-80.064zm-286.258 148.821c-8.508-20.366-12.565-42.519-12.691-68.899-.104-22.183 8.493-43.017 24.208-58.663 15.208-15.141 35.226-23.385 56.387-23.185 12.131.105 23.764 2.868 34.577 8.21 22.767 11.252 48.88 11.25 71.645 0 10.813-5.343 22.446-8.105 34.582-8.211 21.149-.235 41.175 8.042 56.383 23.185 15.715 15.646 24.312 36.48 24.208 58.662-.126 26.381-4.183 48.535-12.691 68.9h-276.608z"></path>
</g></svg></span>
                <h5 class="u-align-center u-text u-text-palette-1-base u-text-9">Crowns</h5>
                <p class="u-align-center u-text u-text-grey-50 u-text-10"> A dental crown, also known as a dental cap, is a custom-made prosthetic covering that is placed over a damaged or decayed tooth to restore its strength, shape, and appearance, while also protecting it from further damage</p>
              </div>
            </div>
            <div class="u-align-center u-container-align-center u-container-style u-grey-5 u-list-item u-repeater-item u-list-item-5" data-animation-direction="Up" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-5"><span class="u-align-center u-icon u-icon-circle u-palette-1-base u-icon-5"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512.01 512.01" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-7933"></use></svg><svg class="u-svg-content" viewBox="0 0 512.01 512.01" id="svg-7933"><path d="m392.01 312.37v-56.365h105c8.284 0 15-6.716 15-15s-6.716-15-15-15h-45v-15c0-8.284-6.716-15-15-15s-15 6.716-15 15v15h-30v-152.574c0-31.665-25.762-57.426-57.427-57.426-15.339 0-29.76 5.973-40.606 16.82l-25.6 25.6c-12.165-8.078-26.431-12.419-41.367-12.419-20.033 0-38.867 7.802-53.032 21.968-5.858 5.858-5.857 15.355 0 21.213l84.852 84.851c2.929 2.929 6.768 4.394 10.606 4.393 3.838 0 7.678-1.465 10.606-4.393 14.166-14.165 21.968-32.999 21.968-53.032 0-14.936-4.342-29.203-12.419-41.367l25.599-25.599c5.181-5.18 12.068-8.033 19.394-8.033 15.123 0 27.427 12.303 27.427 27.426v212.811c-.847-.148-1.707-.237-2.578-.237h-87.423v-30h45c8.284 0 15-6.716 15-15s-6.716-15-15-15h-90c-8.284 0-15 6.716-15 15s6.716 15 15 15h15v30h-26.365l-58.177-58.177c-5.856-5.858-15.354-5.858-21.213 0l-10.605 10.604-21.214-21.214 10.607-10.607c2.813-2.813 4.394-6.628 4.394-10.607s-1.58-7.794-4.394-10.607l-38.214-38.213c-17.546-17.546-46.095-17.544-63.639 0-17.586 17.584-17.589 46.052 0 63.639l38.213 38.213c2.812 2.813 6.628 4.394 10.606 4.394s7.794-1.58 10.606-4.393l10.607-10.607 21.214 21.213-10.605 10.605c-2.813 2.813-4.394 6.628-4.394 10.607s1.58 7.793 4.394 10.607l80.149 80.149c2.812 2.813 6.628 4.393 10.606 4.393h27.422v90h-45c-8.284 0-15 6.716-15 15s6.716 15 15 15h180c8.284 0 15-6.716 15-15s-6.716-15-15-15h-45v-90h26.365l106.456 106.457c8.538 8.735 19.959 13.543 32.179 13.543 24.813 0 45-20.187 45-45 0-12.237-4.821-23.673-13.58-32.215zm-124.376-171.955-60.035-60.034c5.983-2.865 12.581-4.376 19.411-4.376 12.018 0 23.317 4.68 31.816 13.177.001.001.002.002.003.004 8.499 8.499 13.181 19.799 13.181 31.819 0 6.83-1.512 13.427-4.376 19.41zm-233.23 49.196c-5.863-5.863-5.863-15.35 0-21.213 5.848-5.847 15.364-5.85 21.213 0l27.607 27.606-10.602 10.602c-.002.002-.003.003-.005.005s-.003.003-.005.005l-10.602 10.602zm237.606 276.394h-30v-90h30zm195 0c-4.154 0-7.911-1.675-10.596-4.387-15.943-15.942-95.202-95.202-111.22-111.219-2.812-2.813-6.628-4.393-10.606-4.393h-143.787l-65.149-65.149 10.602-10.601c.001-.001.003-.002.004-.003s.002-.003.003-.004l10.601-10.6 51.964 51.964c2.812 2.813 6.628 4.393 10.606 4.393h143.787l13.182 13.182.005.005 111.209 111.209c2.929 2.955 4.396 6.685 4.396 10.604-.001 8.27-6.729 14.999-15.001 14.999z"></path></svg></span>
                <h5 class="u-align-center u-text u-text-palette-1-base u-text-11">emergency care</h5>
                <p class="u-align-center u-text u-text-grey-50 u-text-12"> Dental emergency care provides prompt and expert treatment to address urgent oral health issues, offering relief and peace of mind when unexpected dental problems arise</p>
              </div>
            </div>
            <div class="u-align-center u-container-align-center u-container-style u-grey-5 u-list-item u-repeater-item u-list-item-6" data-animation-direction="Up" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="750">
              <div class="u-container-layout u-similar-container u-valign-top u-container-layout-6"><span class="u-align-center u-icon u-icon-circle u-palette-1-base u-icon-6"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-a7fa"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" id="svg-a7fa"><g><path d="m497 241h-16.512c-7.418-112.137-97.351-202.07-209.488-209.488v-16.512c0-8.284-6.716-15-15-15s-15 6.716-15 15v16.512c-112.137 7.418-202.07 97.351-209.488 209.488h-16.512c-8.284 0-15 6.716-15 15s6.716 15 15 15h16.512c7.418 112.137 97.351 202.07 209.488 209.488v16.512c0 8.284 6.716 15 15 15s15-6.716 15-15v-16.512c112.137-7.418 202.07-97.351 209.488-209.488h16.512c8.284 0 15-6.716 15-15s-6.716-15-15-15zm-226 209.429v-14.429c0-8.284-6.716-15-15-15s-15 6.716-15 15v14.429c-95.591-7.306-172.123-83.838-179.429-179.429h14.429c8.284 0 15-6.716 15-15s-6.716-15-15-15h-14.429c7.306-95.591 83.838-172.123 179.429-179.429v14.429c0 8.284 6.716 15 15 15s15-6.716 15-15v-14.429c95.591 7.306 172.123 83.838 179.429 179.429h-14.429c-8.284 0-15 6.716-15 15s6.716 15 15 15h14.429c-7.306 95.591-83.838 172.123-179.429 179.429z"></path><path d="m327.796 125.015c-24.591-7.385-50.206-4.312-71.796 8.321-21.59-12.634-47.208-15.706-71.803-8.319-29.021 8.718-51.953 32.191-59.845 61.259-6.859 25.257-3.111 50.998 10.552 72.481 10.53 16.556 16.096 36.35 16.096 57.243 0 41.355 33.645 75 75 75 8.284 0 15-6.716 15-15v-60c0-8.271 6.729-15 15-15s15 6.729 15 15v60c0 8.284 6.716 15 15 15 41.355 0 75-33.645 75-75 0-20.893 5.565-40.687 16.095-57.243 13.664-21.483 17.411-47.225 10.553-72.481-7.894-29.072-30.828-52.546-59.852-61.261zm23.984 117.643c-13.594 21.375-20.78 46.737-20.78 73.342 0 19.556-12.539 36.239-30 42.43v-42.43c0-24.813-20.187-45-45-45s-45 20.187-45 45v42.43c-17.461-6.191-30-22.873-30-42.43 0-26.605-7.186-51.967-20.781-73.343-9.08-14.275-11.535-31.507-6.915-48.52 5.121-18.861 20.635-34.715 39.524-40.388 19.144-5.75 38.366-2.356 54.128 9.557 5.351 4.044 12.737 4.045 18.088 0 15.761-11.912 34.98-15.307 54.123-9.559 18.892 5.673 34.407 21.527 39.529 40.39 4.62 17.014 2.164 34.245-6.916 48.521z"></path>
</g></svg></span>
                <h5 class="u-align-center u-text u-text-palette-1-base u-text-13">Extractions</h5>
                <p class="u-align-center u-text u-text-grey-50 u-text-14"> Dental extractions, commonly known as tooth extractions, involve the removal of one or more teeth from the mouth, typically due to severe damage, decay, infection, or orthodontic reasons</p>
              </div>
            </div>
          </div>
        </div>
        <a href="https://nicepage.app" class="u-active-black u-align-center u-btn u-button-style u-hover-black u-palette-1-base u-text-active-white u-text-body-alt-color u-text-hover-white u-btn-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="1750">Contact us</a>
      </div>
    </section>
    <section class="u-align-center u-clearfix u-grey-5 u-section-5" id="carousel_bd14">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="data-layout-selected u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-row">
              <div class="u-container-style u-image u-layout-cell u-size-37 u-image-1" data-image-width="1200" data-image-height="800" data-animation-name="customAnimationIn" data-animation-duration="1500">
                <div class="u-container-layout u-container-layout-1">
                  <div class="u-align-left u-container-style u-custom-color-1 u-expanded-width u-group u-shape-rectangle u-group-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="750">
                    <div class="u-container-layout u-container-layout-2">
                      <h2 class="u-align-left u-text u-text-1">General<br>Dentist &amp; Prosthodontist
                      </h2>
                      <a href="https://nicepage.com/k/announcement-html-templates" class="u-active-palette-1-light-3 u-align-left u-btn u-button-style u-hover-palette-1-light-3 u-text-active-black u-text-hover-black u-text-palette-1-base u-white u-btn-1">Book Appointment</a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-size-23 u-layout-cell-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                <div class="u-container-layout u-container-layout-3">
                  <h5 class="u-align-left u-text u-text-palette-1-base u-text-2">Highly Experienced Team<br>
                  </h5>
                  <p class="u-align-center u-text u-text-3"> "Here at ORAL HOME, we take pride in our high-expertise dental team dedicated to our Dental Home Service. Our experienced and compassionate professionals are committed to delivering the highest quality of dental care in the comfort of your home, ensuring that you receive the expert care you deserve.</p>
                  <div class="custom-expanded u-align-left u-border-1 u-border-grey-30 u-line u-line-horizontal u-line-1"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-custom-color-1 u-section-6" id="carousel_5cf2">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="data-layout-selected u-clearfix u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-col">
              <div class="u-container-style u-layout-cell u-size-30 u-layout-cell-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                <div class="u-container-layout u-valign-top u-container-layout-1">
                  <h2 class="u-text u-text-1">Our Mission</h2>
                  <ul class="u-text u-text-2">
                    <li> Our mission is to transform the way people experience dental care. We understand that visiting a traditional dental clinic can be daunting for many individuals, whether due to anxiety, mobility issues, or a busy schedule.&nbsp;</li>
                    <li>That's why we've made it our mission to bring the dentist's office to you. Our team of highly skilled and compassionate dental professionals is committed to providing comprehensive, personalized dental care to meet your unique needs</li>
                  </ul>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-size-30 u-layout-cell-2" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="750">
                <div class="u-container-layout u-valign-bottom-md u-valign-bottom-sm u-valign-bottom-xs u-container-layout-2">
                  <h2 class="u-text u-text-3">Our Values</h2>
                  <ul class="u-text u-text-4">
                    <li>It will help us offer our patients a better experience when under our care and will increase staff awareness to become better engaged with the mission and vision of the organization. </li>
                    <li> Meet the dedicated professionals who make it all possible. Our team is comprised of experienced dentists and dental hygienists who share a passion for making dental care a positive experience. We are committed to providing exceptional care with a gentle touch.</li>
                    <li>.<br>
                    </li>
                  </ul>
                  <a href="https://nicepage.cloud" class="u-active-palette-1-light-3 u-btn u-button-style u-hover-palette-1-light-3 u-text-active-black u-text-hover-black u-text-palette-1-base u-white u-btn-1">contact us</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-image u-section-7" id="carousel_9493" data-image-width="509" data-image-height="339">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-container-align-left u-container-style u-group u-white u-group-1" data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="750">
          <div class="u-container-layout u-container-layout-1">
            <h2 class="u-align-left u-text u-text-1">High Quality Treatment&nbsp;</h2>
            <p class="u-align-left u-text u-text-2"> At Oral Home, we are dedicated to providing high-quality dental treatment through our Dental Home Services. Our commitment to excellence ensures that you receive the best possible care and treatment in the comfort of your own home. With a focus on quality, safety, and patient satisfaction, we strive to deliver the superior dental care you deserve.".</p>
            <a href="https://nicepage.com/c/gallery-html-templates" class="u-active-black u-align-left u-border-none u-btn u-button-style u-hover-black u-palette-1-base u-text-active-white u-text-body-alt-color u-text-hover-white u-btn-1">book now</a>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-white u-section-8" id="carousel_6d59">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-align-center u-container-style u-custom-color-1 u-expanded-width-xs u-group u-group-1">
          <div class="u-container-layout u-valign-middle-xl u-valign-middle-xs u-container-layout-1">
            <h1 class="u-text u-text-1">Contact Us</h1>
            <div class="u-align-left u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-form u-form-1">
              <form action="https://forms.nicepagesrv.com/v2/form/process" class="u-clearfix u-form-spacing-28 u-form-vertical u-inner-form" style="padding: 10px" source="email" name="form">
                <div class="u-form-group u-form-name">
                  <label for="name-5a14" class="u-form-control-hidden u-label" wfd-invisible="true">Name</label>
                  <input type="text" placeholder="Enter your Name" id="name-5a14" name="name" class="u-input u-input-rectangle" required="">
                </div>
                <div class="u-form-email u-form-group">
                  <label for="email-5a14" class="u-form-control-hidden u-label" wfd-invisible="true">Email</label>
                  <input type="email" placeholder="Enter a valid email address" id="email-5a14" name="email" class="u-input u-input-rectangle" required="">
                </div>
                <div class="u-form-group u-form-message">
                  <label for="message-5a14" class="u-form-control-hidden u-label" wfd-invisible="true">Message</label>
                  <textarea placeholder="" rows="4" cols="50" id="message-5a14" name="message" class="u-input u-input-rectangle" required=""></textarea>
                </div>
                <div class="u-align-center u-form-group u-form-submit">
                  <a href="#" class="u-active-white u-border-2 u-border-white u-btn u-btn-submit u-button-style u-hover-white u-none u-text-hover-palette-2-base u-text-palette-2-base u-btn-1">Submit</a>
                  <input type="submit" value="submit" class="u-form-control-hidden" wfd-invisible="true">
                </div>
                <div class="u-form-send-message u-form-send-success" wfd-invisible="true"> Thank you! Your message has been sent. </div>
                <div class="u-form-send-error u-form-send-message" wfd-invisible="true"> Unable to send your message. Please fix errors then try again. </div>
                <input type="hidden" value="" name="recaptchaResponse" wfd-invisible="true">
                <input type="hidden" name="formServices" value="f5a92450-8d9a-eb07-0ef5-691e7605e531">
              </form>
            </div>
          </div>
        </div>
        <div class="u-expanded-width-md u-expanded-width-sm u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-align-center u-container-style u-list-item u-repeater-item u-white u-list-item-1">
              <div class="u-container-layout u-similar-container u-valign-bottom u-container-layout-2"><span class="u-icon u-icon-circle u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-9f82"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" id="svg-9f82" style="enable-background:new 0 0 512 512;"><g><g><path d="M507.49,101.721L352.211,256L507.49,410.279c2.807-5.867,4.51-12.353,4.51-19.279V121    C512,114.073,510.297,107.588,507.49,101.721z"></path>
</g>
</g><g><g><path d="M467,76H45c-6.927,0-13.412,1.703-19.279,4.51l198.463,197.463c17.548,17.548,46.084,17.548,63.632,0L486.279,80.51    C480.412,77.703,473.927,76,467,76z"></path>
</g>
</g><g><g><path d="M4.51,101.721C1.703,107.588,0,114.073,0,121v270c0,6.927,1.703,13.413,4.51,19.279L159.789,256L4.51,101.721z"></path>
</g>
</g><g><g><path d="M331,277.211l-21.973,21.973c-29.239,29.239-76.816,29.239-106.055,0L181,277.211L25.721,431.49    C31.588,434.297,38.073,436,45,436h422c6.927,0,13.412-1.703,19.279-4.51L331,277.211z"></path>
</g>
</g></svg></span>
                <h5 class="u-text u-text-2">Email</h5>
                <p class="u-text u-text-3">
                  <a href="mailto:hello@theme.com" class="u-active-none u-border-1 u-border-no-left u-border-no-right u-border-no-top u-border-palette-2-base u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-2-base u-btn-2"> WEBSITESAVEETHA@GMAIL.COM</a>
                </p>
              </div>
            </div>
            <div class="u-align-center u-container-style u-list-item u-repeater-item u-white u-list-item-2">
              <div class="u-container-layout u-similar-container u-valign-bottom u-container-layout-3"><span class="u-icon u-icon-circle u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 513.64 513.64" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-9786"></use></svg><svg class="u-svg-content" viewBox="0 0 513.64 513.64" x="0px" y="0px" id="svg-9786" style="enable-background:new 0 0 513.64 513.64;"><g><g><path d="M499.66,376.96l-71.68-71.68c-25.6-25.6-69.12-15.359-79.36,17.92c-7.68,23.041-33.28,35.841-56.32,30.72    c-51.2-12.8-120.32-79.36-133.12-133.12c-7.68-23.041,7.68-48.641,30.72-56.32c33.28-10.24,43.52-53.76,17.92-79.36l-71.68-71.68    c-20.48-17.92-51.2-17.92-69.12,0l-48.64,48.64c-48.64,51.2,5.12,186.88,125.44,307.2c120.32,120.32,256,176.641,307.2,125.44    l48.64-48.64C517.581,425.6,517.581,394.88,499.66,376.96z"></path>
</g>
</g></svg></span>
                <h5 class="u-text u-text-4">phone number</h5>
                <p class="u-text u-text-5"> +91 893999424<br>landline number:<br>+044 26801583
                </p>
              </div>
            </div>
            <div class="u-align-center u-container-style u-list-item u-repeater-item u-white u-list-item-3">
              <div class="u-container-layout u-similar-container u-valign-bottom u-container-layout-4"><span class="u-icon u-icon-circle u-text-palette-1-base u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 52 52" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-077e"></use></svg><svg class="u-svg-content" viewBox="0 0 52 52" x="0px" y="0px" id="svg-077e" style="enable-background:new 0 0 52 52;"><path style="fill:currentColor;" d="M38.853,5.324L38.853,5.324c-7.098-7.098-18.607-7.098-25.706,0h0
	C6.751,11.72,6.031,23.763,11.459,31L26,52l14.541-21C45.969,23.763,45.249,11.72,38.853,5.324z M26.177,24c-3.314,0-6-2.686-6-6
	s2.686-6,6-6s6,2.686,6,6S29.491,24,26.177,24z"></path></svg></span>
                <h5 class="u-text u-text-6">HOSPITAL ADDRESS&nbsp;</h5>
                <p class="u-text u-text-7"> 162, Poonamallee High Rd, Velappanchavadi, Chennai, Tamil Nadu 600077</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-c07e"><div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">Powered By saveetha&nbsp;</p>
      </div></footer>
    <section class="u-backlink u-clearfix u-grey-80">
      <a class="u-link" href="https://nicepage.com/website-templates" target="_blank">
        <span>Website Templates</span>
      </a>
      <p class="u-text">
        <span>created with</span>
      </p>
      <a class="u-link" href="" target="_blank">
        <span>Website Builder Software</span>
      </a>. 
    </section>
  
</body></html>