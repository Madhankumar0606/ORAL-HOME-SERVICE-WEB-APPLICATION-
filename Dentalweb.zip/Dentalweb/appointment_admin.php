<?php
include('connection.php');

// Function to get all active appointments
function getAllActiveAppointments($table)
{
    global $con;
    $query = "SELECT * FROM $table";
    return $query_run = mysqli_query($con, $query);
}

$appointments = getAllActiveAppointments("appointment");

// Function to get all doctors
function getAllDoctors()
{
    global $con;
    $query = "SELECT * FROM doctor_register";
    return $query_run = mysqli_query($con, $query);
}

// Check if the form is submitted for sending to the doctor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sendToDoctor'])) {
    $idToSendToDoctor = $_POST['idToSendToDoctor'];
    $selectedDoctorId = $_POST['selectedDoctor'];

    // Check if the appointment status is 'declined'
    $statusCheckQuery = "SELECT appointment_status FROM appointment WHERE id = $idToSendToDoctor";
    $statusCheckResult = mysqli_query($con, $statusCheckQuery);

    if ($statusCheckResult) {
        $statusData = mysqli_fetch_assoc($statusCheckResult);
        $appointmentStatus = $statusData['appointment_status'];

        if ($appointmentStatus == 'declined') {
            // Update the 'appointment_status' to empty
            $updateStatusQuery = "UPDATE appointment SET appointment_status = '' WHERE id = $idToSendToDoctor";
            $updateStatusQueryRun = mysqli_query($con, $updateStatusQuery);

            if ($updateStatusQueryRun) {
                // Update the 'doctor_id' field in the 'appointment' table.
                $updateQuery = "UPDATE appointment SET doctor_id = '$selectedDoctorId' WHERE id = $idToSendToDoctor";
                $updateQueryRun = mysqli_query($con, $updateQuery);

                if ($updateQueryRun) {
                    echo '<script>alert("Appointment sent to doctor successfully");</script>';
                    echo '<script>window.location.href = "appointment_admin.php";</script>';
                } else {
                    echo "Error updating appointment: " . mysqli_error($con);
                }
            } else {
                echo "Error updating appointment status: " . mysqli_error($con);
            }
        } else {
            // If status is not 'declined', proceed as usual
            $updateQuery = "UPDATE appointment SET doctor_id = '$selectedDoctorId' WHERE id = $idToSendToDoctor";
            $updateQueryRun = mysqli_query($con, $updateQuery);

            if ($updateQueryRun) {
                echo '<script>alert("Appointment sent to doctor successfully");</script>';
                echo '<script>window.location.href = "appointment_admin.php";</script>';
            } else {
                echo "Error updating appointment: " . mysqli_error($con);
            }
        }
    } else {
        echo "Error checking appointment status: " . mysqli_error($con);
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">
    <title>Admin Panel</title>
    <!-- Add your styles or links to external stylesheets here -->
    <style>
      
      #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }
        *
        {
            margin:0;
            padding:0;
            font-family: 'Inter', sans-serif;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }

      
      

        .appointmentDetails {
          
            padding: 10px;
            margin:10px 50px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color:white;
            
        }
        .user{
            display:flex;
            justify-content:space-between;
        }

        strong {
          
            margin: 10px;
           
            display: inline-block;
            width: 150px; 
            text-align: right;
        }

        .appointmentDetails div {
            
        }

        .date {
            font-size: 0.8em;
            color: #888;
        }

        .noAppointment {
            text-align: center;
            font-style: italic;
            color: #888;
        }

        .appointmentInfo {
            display: inline-block;
                color:rgb(0, 99, 160);
            font-weight:700px;
        }
        .box
        {
            display:flex;
            justify-content:space-between;
        }
        .title
        {
            background-color:black;
            color:white;
            padding:10px;
        }
        .viewbutton
        {
            padding: 6px 20px;
            border-radius:5px;
            color:white;
            background-color:#126983;
            border:none;
            margin:10px;
        }
        .deletebutton
        {
            padding: 6px 20px;
            border-radius:5px;
            color:white;
            background-color:red;
            border:none;
            margin:10px;
        }
        .button a{
           
            text-decoration:none;
        }
        .sendtodocbutton
        {
            padding: 6px 20px;
            border-radius:5px;
            color:white;
            background-color:#126983;
            border:none;
            margin:10px;

        }
        select{
            padding:2px 40px;
            border-radius:5px;
            background:#f2f2f2;
            
        }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>
    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="LOGO1.Png">
        </div>

        <section class="details">
            <?php
            if (mysqli_num_rows($appointments) > 0) {
                foreach ($appointments as $item) {
            ?>
                    <div class="appointmentDetails">
                        <div class="user">
                            <div class="details">
                                <div><strong>Name:</strong><span class="appointmentInfo"><?= $item['name'] ?></span></div>
                                <div><strong>Age:</strong><span class="appointmentInfo"><?= $item['age'] ?></span></div>
                                <div><strong>Gender:</strong><span class="appointmentInfo"><?= $item['gender'] ?></span></div>
                                <div><strong>Phone:</strong><span class="appointmentInfo"><?= $item['phone'] ?></span></div>
                                <div><strong>Email:</strong><span class="appointmentInfo"><?= $item['email'] ?></span></div>
                                <div><strong>Address:</strong><span class="appointmentInfo"><?= $item['address'] ?></span></div>
                            </div>
                            <div class="button">
                                <form action="" method="post">
                                    <input type="hidden" name="idToSendToDoctor" value="<?= $item['id'] ?>">
                                    <div class="form-group">
                                        <label for="selectedDoctor">Select Doctor:</label>
                                        <select name="selectedDoctor" id="selectedDoctor" required>
                                            <option value="">Select Doctor</option>
                                            <?php
                                            $doctors = getAllDoctors();
                                            while ($doctor = mysqli_fetch_assoc($doctors)) {
                                                echo '<option value="' . $doctor['id'] . '">' . $doctor['name'] . '</option>';
                                            }
                                            ?>
                                        </select>
                                        <button type="submit" name="sendToDoctor" class="sendtodocbutton">Send to Doctor</button>
                                    </div>
                                   
                                </form>
                                <div><strong>Status:</strong>
                                <span class="appointmentInfo" style="font-size:30px; color: <?= ($item['appointment_status'] == 'accepted') ? 'green' : (($item['appointment_status'] == 'declined') ? 'red' : 'black'); ?>">
    <?= $item['appointment_status'] ?>
</span>

   
</div>

                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
            ?>
                <div class="noAppointment">No appointments yet.</div>
            <?php
            }
            ?>
        </section>
    </div>

   <script src="admin.js"></script>
</body>

</html>