<?php
include('connection.php');

// Function to export CSV and force download
function exportCSV($data, $filename) {
    // Save as CSV
    $csvFile = fopen($filename, 'w');

    // Write CSV header
    fputcsv($csvFile, array_keys($data[0]));

    // Write CSV data
    foreach ($data as $row) {
        fputcsv($csvFile, $row);
    }

    fclose($csvFile);

    // Output file for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
    readfile($filename);

    // Flush and close output buffer
    ob_flush();
    flush();
}

// Database connection using PDO
try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Set character set (replace 'utf8mb4' with the appropriate character set)
    $pdo->exec("SET NAMES utf8mb4");

    // Query to join appointment and register tables
    $query = "SELECT appointment.*, register.* FROM appointment
              INNER JOIN register ON appointment.user_id = register.id";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $joinedData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Close the database connection
    $pdo = null;

    // Check if the button is clicked
    if (isset($_POST['downloadJoinedData'])) {
        // Trigger CSV export for joined data
        exportCSV($joinedData, 'uploads/joined_data.csv');
        echo "CSV file for Joined Data successfully created and downloaded.";
        exit; // Stop further execution after download
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Add User</title>
    <style>
        /* Add your styles here if needed */
        #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }
        .fa-user-plus{
            margin:5px 10px;
          
        }

        .container {
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .button {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .user button, .user button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color:#126983;
            color: white;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .user button:hover, .user button:hover {
            background-color:rgb(0, 99, 160);
        }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>
     <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="LOGO1.Png">
        </div>

      <div class="container">
      <!--  <form method="post">
            <div class="button">
                <div class="user">
                    <button type="submit" name="downloadUserDetails">Download CSV File UserDetails</button>
                </div>
            </div>
        </form>-->
        <form method="post">
        <div class="button">
            <div class="user">
                <button type="submit" name="downloadJoinedData">Download CSV File User Details & Appointments</button>
            </div>
        </div>
    </form>
        <form method="post">
            <div class="button">
                <div class="user">
                    <button type="submit" name="downloadDoctorDetails">Download CSV File Doctor Details</button>
                </div>
            </div>
        </form>
     
    </div>
    </div>

    
    <script src="admin.js"></script>
</body>

</html>
