<?php

include('header.html');


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bookingtype.css">
    <title>Appointment</title>
</head>
<body>
    <div>
    <div class="type">
    <div class="appointtype">
    <form method="post" action="process_booking.php">
    <div class="booking">
        
        <button type="submit" name="booking_type" value="SMS" class="selectbtn"><i class="fa fa-comments"></i>Booking Through SMS</button>
    </div>
    <div class="booking">
        <button type="submit" name="booking_type" value="Normal Call" class="selectbtn"><i class="fa fa-phone"></i>Booking Through  Normal Call</button>
    </div>
    <div class="booking">
        <button type="submit" name="booking_type" value="Video Call" class="selectbtn"><i class="fa fa-video-camera"></i>Booking Through Video Call</button>
    </div>
</form>

</div>
</div>
<?php
include('footer.php');
?>
</body>

</html>
