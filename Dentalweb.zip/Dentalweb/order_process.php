<?php
include('header.html');
include('function.php');
include('connection.php');


// function.php - Functions for order processing
function generateTrackingNumber() {
    // Generate a unique tracking number (you can customize this based on your requirements)
    return uniqid('TRK');
}

function storeOrderDetails($tracking_no, $total_price, $user_email, $user_address, $user_phone) {
    global $con;

    // Store order details in the database
    $sql = "INSERT INTO orders (tracking_no, total_price, email, address, phone) VALUES ('$tracking_no', '$total_price', '$user_email', '$user_address', '$user_phone')";

    if ($con->query($sql) === TRUE) {
        return true;
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
        return false;
    }
}

// orders.php - Order processing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payPrice'])) {
    $userId=$_SESSION['auth_user']['user_id'];
    $tracking_no = generateTrackingNumber();
    $total_price = $overallTotal; // Assuming $overallTotal is available from the previous page
    $user_email = $_POST['email']; // Assuming you have an email field in your form
    $user_address = $_POST['address']; // Assuming you have an address field in your form
    $user_phone = $_POST['phone']; // Assuming you have a phone field in your form

    // Store order details in the database
    $success = storeOrderDetails($tracking_no, $total_price, $user_email, $user_address, $user_phone);

    if ($success) {
        echo "Order placed successfully. Your tracking number is $tracking_no.";
    } else {
        echo "Failed to place the order. Please try again.";
    }
}
?>