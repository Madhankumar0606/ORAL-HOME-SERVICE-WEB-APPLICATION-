<?php
include('function.php');
include('connection.php');
include('header.html');

if (!isset($_SESSION['auth_user']['user_id'])) {
    header('location: login_register.php');
    exit();
}

$userId = $_SESSION['auth_user']['user_id'];
$itemsQuery = "SELECT * FROM orders WHERE user_id='$userId'";
$itemsResult = $con->query($itemsQuery);

$itemCount = $itemsResult->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cartpage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Cart</title>
    <style>
        /* Add your custom styles here */
    </style>
</head>
<body>
    
    <div class="body">
        <div class="container">
            <?php
            while ($citem = $itemsResult->fetch_assoc()) {
            ?>
            <div class="cart-item">
                <div class="item-details">
                    <div class="details">
                        <h5><?= $citem['email'] ?></h5>
                       <h5><?=$citem['total_price']?></h5>
                    </div>
                </div>
            </div>
            <?php
            }
            ?>
        </div>
    </div>
    <script>
        // Add your JavaScript code here
    </script>
</body>

</html>
