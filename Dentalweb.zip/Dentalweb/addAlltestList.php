<?php

include('function.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="addAlltestList.css">
    <link rel="stylesheet" href="adminSidebar.css">
    

    <title>Add Test Details</title>
    <style>
     #add{
         text-align:center;
         margin:10px;
     }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="LOGO1.Png">
        </div>
    <div class="body">
        <div class="category">
            <h2 id="add">Add Test Details</h2>
            <form action="adding_detailsAdmin.php" method="post" enctype="multipart/form-data">

                <div class="section">
                    <div class="labeltype">
                        <label for="test_id">Select Test Type</label>
                    </div>
                    <div class="inputtype">
                        <select class="selctcategory" name="test_id">
                            <option selected>Select Type</option>
                            <?php
                            $testType = getAll("testtype");
                            if (mysqli_num_rows($testType) > 0) {
                                foreach ($testType as $item) {
                            ?>
                                    <option value="<?= $item['id']; ?>"><?= $item['name']; ?></option>
                            <?php
                                }
                            } else {
                                echo "No categories available";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="section">
                    <div class="labeltype">
                        <label for="name">Name</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="name" id="name" required>
                    </div>
                </div>

                <div class="section">
                    <div class="labeltype">
                        <label for="slug">Slug</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="slug" id="slug" required>
                    </div>
                </div>

                <div class="section">
                    <div class="labeltype">
                        <label for="original_price">Original Price</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="original_price" id="original_price" required>
                    </div>
                </div>

                <div class="section">
                    <div class="labeltype">
                        <label for="selling_price">Selling Price</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="selling_price" id="selling_price" required>
                    </div>
                </div>

                <div class="section">
                    <div class="labeltype">
                        <label for="image">Upload Image</label>
                    </div>
                    <div class="inputtype">
                        <input type="file" name="image" id="image">
                    </div>
                </div>

                <div class="add">
                    <button type="submit" name="addproduct" class="button">Save</button>
                </div>

            </form>
        </div>
    </div>
                        </div>
                        <script src="admin.js"></script>
</body>

</html>
