<?php
session_start();
include('header.html');

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    // User is not authenticated, redirect to the login page
    header('Location: login_register.php');
    exit(); // Stop further execution of the script
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="userProfile.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
      
    </style>
    <title>Profile</title>
</head>

<body>
<div class="body">
    <div class="boxContainer">
   
<span class="iconbox"><i class="fa fa-user"></i></span>
                
                    <div class="user-profile">
                        <?php
                        if (isset($_SESSION['auth_user']['name'])) {
                            echo 'Welcome, ' . $_SESSION['auth_user']['name'];
                        } else {
                            echo 'Guest'; // You can customize the message for users who are not logged in
                        }
                        ?>
                    </div>
                    
                    </div>
 
        <div class="container">
            <div class="row">
                <div class="profile">
                 <a href="editprofile.php">   <i class="fa fa-edit"></i>Edit Profile</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="my-orders.php"><i class="fa fa-medkit"></i>Track Your Orders</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="rate.php"><i class="fa fa-star"></i>Rate Us</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="Terms & Conditions.php"><i class="fa fa-question-circle"></i>Terms & Conditions</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="privacy.php"><i class="fa fa-question-circle"></i>Privacy Policy</a>
                </div>
            </div>
            <div class="row">
                <div class="profile">
                <a href="logout.php"> <i class="fa fa-sign-out"></i>Log Out</a>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
