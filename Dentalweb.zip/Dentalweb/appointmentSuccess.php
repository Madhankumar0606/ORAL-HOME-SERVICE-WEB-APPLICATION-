<?php
session_start(); // Start the session
include('header.html');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="appointmentSuccess.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Appointment Success</title>
    <style>
     .call{
    margin:0px 100px;
     }
       
    </style>
</head>
<body>
    <?php
    include('connection.php'); // Include your database connection file

    if (isset($_SESSION['booking_type'])) {
        $booking_type = $_SESSION['booking_type'];
        echo '<div class="container">';
        echo '<div class="success-container">';
        echo '<div class="iconbox">';
        echo '<div class="icon"><i class="fa fa-check-circle"></i></div>';
        echo '</div>';

        echo '<div class="successMsg">';
        echo '<h3>Thank You for Filling The Form</h3>';

        if ($booking_type == 'SMS') {
            echo '<h6>We will kindly send our Doctor ASAP!<br>';
            echo 'Upcoming Details of your appointment booking will be sent through email or message shortly.</h6>';
        } elseif ($booking_type == 'Video Call') {
            echo '<h6><a href="https://meet.google.com/zqt-jcsy-exb" target="_blank">https://meet.google.com/zqt-jcsy-exb</a><br>';
            echo 'Click this link to join the video call for booking appointment.<br>';
            echo 'After finishing the booking, you will receive details of the doctor.</h6>';
        } elseif ($booking_type == 'Normal Call') {
            echo '<h6>We will make contact with you shortly for booking appointments.<br>';
            echo 'After calling, details of the doctor for home visit will be sent to you.</h6>';
            echo '<a href="tel:9989898999" class="call">Call us now at 9989898999</a>';
        }

        echo '</div>';
        echo '<div class="button"><a href="appointment.php"><button type="sumbit" name="backbtn">Back To Appointment</a></button>';
        echo '<div>';
        echo '</div>';
      echo '</div>';
        unset($_SESSION['booking_type']); // Clear the session variable
    }
   
    ?>
    
</body>
</html>
