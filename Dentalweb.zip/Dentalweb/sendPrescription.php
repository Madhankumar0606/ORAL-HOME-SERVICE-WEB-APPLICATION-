<?php
session_start();

// Include the connection file
include('connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sendPrescription'])) {
    $prescriptionId = $_POST['prescriptionId'];

    // Your logic to send the prescription goes here
    // For example, you can update the database to mark it as sent
    // ...

    // Assuming you have a column named 'sent_status' in the 'prescription' table
    $updateQuery = "UPDATE prescription SET sent_status = 'sent' WHERE id = $prescriptionId";
    $updateQueryRun = mysqli_query($con, $updateQuery);

    if ($updateQueryRun) {
        echo '<script>alert("Prescription sent successfully");</script>';
        echo '<script>window.location.href = "viewPrescription.php";</script>';
    } else {
        echo "Error sending prescription: " . mysqli_error($con);
    }
}
?>
