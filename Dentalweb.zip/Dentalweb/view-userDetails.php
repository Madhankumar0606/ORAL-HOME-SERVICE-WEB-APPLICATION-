<?php

include('function.php');



if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $user_data = getByID("register", $id);

    if ($user_data && mysqli_num_rows($user_data) > 0) {
        $data = mysqli_fetch_array($user_data);
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="adminSideBar.css">
<link rel="stylesheet" href="form.css">
    <title>View</title>
    <style>
        /* Add your styles here if needed */
        #sidebar ul ul {
            display: none; /* Hide sublists by default */
        }
    </style>
</head>

<body>
<div class="header"></div>
    <div id="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li>
                <a href="#" onclick="toggleSublist('userDetails')">User</a>
                <ul id="userDetails">
                    <li><a href="user_view.php">Add/Delete User Database</a></li>
                    <li><a href="prescription_send_patient.php">Prescription Send</a></li>
                </ul>
            </li>
              <li>
            <a href="#" onclick="toggleSublist('doctor')">Doctor</a>
           
                <ul id="doctor">
                    <li><a href="allDoctor.php">All Doctor</a></li>
                    <li><a href="availableDoctor.php">Available Doctor</a></li>
                    <li><a href="unavailableDoctor.php">Unavailable Doctor</a></li>
                   
                    <li><a href="holiday.php">Holiday Doctor</a></li>
                </ul>
            </li>
         
            <li>
            <a href="#" onclick="toggleSublist('appointment')">All Appointments</a>
          
                <ul id="appointment">
                    <li><a href="appointment_admin.php">Send Appointment To Doctor</a></li>
                    <li><a href="All_appointment.php">All Appointment</a></li>
                </ul>
            </li>
            <li>
                <a href="#" onclick="toggleSublist('orders')">Test Enquiry</a>
                <ul id="orders">
                    <li><a href="allorder-admin.php">All Enquriy</a></li>
                    <li><a href="clinic.php">Test Appointment Date</a></li>
                    <li><a href="onlinepaymentOrder.php">Online Payment</a></li>
                    <li><a href="offlinepaymentOrder.php">Offline Payment</a></li>
                </ul>
            </li>
            <li>
            <a href="#" onclick="toggleSublist('test')">Lab Test</a>
           
                <ul id="test">
                    <li><a href="addTest.php">Add Lab Test</a></li>
                    <li><a href="addAlltestList.php">Add Test</a></li>
                    <li><a href="alltestAdd_admin.php">All Test</a></li>
                   
                </ul>
            </li>
            <li><a href="feedback_admin.php">Feedback </a></li>
            <li><a href="backup.php">Save & Backup Database</a></li>
            <li><a href="admin_logout.php">Logout</a></li>
        </ul>
    </div>

    <div id="content">
        <div class="header">
            <div id="sidebarCollapse">
                <i onclick="toggleSidebar()">☰</i>
            </div>
            <img src="ourdental.png">
        </div>
    <div class="body">
     
        <div class="category">
            <div class="body">
                <form action="adding_detailsAdmin.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?= $data['id'] ?>">
                    
                    <div class="labeltype">
                        <label for="name" id="name">Name</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="name" id="name" value="<?= $data['name'] ?>">
                    </div>

                    <div class="labeltype">
                        <label for="email" id="email">Email</label>
                    </div>
                    <div class="inputtype">
                        <input type="email" name="email" id="email" value="<?= $data['email'] ?>">
                    </div>
                    <div class="labeltype">
                        <label for="age" id="age">Age</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="age" id="age" value="<?= $data['age'] ?>">
                    </div>
                    <div class="labeltype">
                        <label for="gender" id="gender">Gender</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="gender" id="gender" value="<?= $data['gender'] ?>">
                    </div>
                    <div class="labeltype">
                        <label for="phone" id="phone">Phone Number</label>
                    </div>
                    <div class="inputtype">
                        <input type="text" name="phone" id="phone" value="<?= $data['phone'] ?>">
                    </div>


                    <div class="labeltype">
                        <label for="password" id="password">Password</label>
                    </div>
                    <div class="inputtype">
                        <input type="password" name="password" id="password" value="<?= $data['password'] ?>">
                    </div>
                    <div class="labeltype">
                        <label for="password" id="password">Password</label>
                    </div>
                    <div class="inputtype">
                        <input type="password" name="cpassword" id="cpassword" value="<?= $data['cpassword'] ?>">
                    </div>


                    <div class="add">
                        <button type="submit" name="updateprofileAdmin" class="button">Update</button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
    
    </div>

  <script src="admin.js"></script>
</body>

</html>
<?php
    } else {
        echo "User not found";
    }
} else {
    echo "User ID not provided";
}
?>